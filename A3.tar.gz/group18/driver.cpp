#include "scanner.hh"
#include "parser.tab.hh"
#include "ast.hh"
#include "codegen.hh"

#include <fstream>
#include <map>
#include <string>
#include <climits>

using namespace std;

SymTab gst;
SymTab gstfun, gststruct;
string filename;
extern std::map<std::string, abstract_astnode*> ast;
std::map<std::string, datatype> predefined {
          	{"printf", createtype(VOID_TYPE)},
          	{"scanf", createtype(VOID_TYPE)}
};
// alias mygcc="gcc-8 -fno-asynchronous-unwind-tables -fno-exceptions -fno-pic -fno-stack-protector -mpreferred-stack-boundary=2 -m32"

int main(int argc, char **argv){
	
	fstream in_file;
	in_file.open(argv[1], ios::in);

	CodeGen generator;

	IPL::Scanner scanner(in_file);
	IPL::Parser parser(scanner);

#ifdef YYDEBUG
	parser.set_debug_level(1);
#endif
	parser.parse();

	// create gstfun with function entries only
	for (const auto& entry : gst.entries){
		if (entry.second.varfun == "fun")
			gstfun.entries[entry.first] = entry.second;
	}

	// create gststruct with struct entries only
	for (const auto& entry : gst.entries){
		if (entry.second.varfun == "struct")
			gststruct.entries[entry.first] = entry.second;
	}

	// // start the JSON printing
	// cout << "{\"globalST\": [\n";
	// gst.print(true);
	// cout << "],\n";
	// cout << "\"structs\": [";
	// for (auto it = gststruct.entries.begin(); it != gststruct.entries.end(); ++it){
	// 	cout << "\n{\n";
	// 	cout << "\"name\": "
	// 		 << "\"" << it->first << "\",\n";
	// 	cout << "\"localST\": [";
	// 	it->second.symtab->print(false);
	// 	cout << "]\n";
	// 	cout << "}";
	// 	cout << (next(it, 1) != gststruct.entries.end() ? "," : "\n");
	// }

	// cout << "],\n";
	// cout << "\"functions\": [";

	// for (auto it = gstfun.entries.begin(); it != gstfun.entries.end(); ++it){
	// 	cout << "\n{\n";
	// 	cout << "\"name\": "
	// 		 << "\"" << it->first << "\",\n";
	// 	cout << "\"localST\": [";
	// 	it->second.symtab->print(false);
	// 	cout << "]\n,\n";
	// 	cout << "\"ast\": ";
	// 	ast[it->first]->print();
	// 	cout << "}";
	// 	cout << (next(it, 1) != gstfun.entries.end() ? "," : "\n");
	// }

	// cout << "]\n}\n";

	std::map<std::string, std::vector<Instr>> code;
	generator.set_gst(&gst);

	for (auto it = gstfun.entries.begin(); it != gstfun.entries.end(); ++it){
		generator.fill_stack();
		auto root = ast[it->first];
		// cout << "here1\n";
		generator.attribution(root);
		// cout << "here3\n";
		int min_offset = 0;
		for (const auto& entry : it->second.symtab->entries){
			if (entry.second.scope == "local")
				min_offset = std::min(min_offset, entry.second.offset);
			// if (entry.second.t.t == STRUCT_TYPE){
			// 	// std::cout << "driver: " << entry.second.type_name << " " << entry.second.offset << "\n";
			// 	// generator.add_type_name(entry.second.offset, entry.second.type_name);
			// } 
			// arrays == death 
		}
		// std::cout << it->first << "\n";
		// generator.print_type_names();
		
		generator.set_temp_offset(min_offset);
		generator.gencode(root, code[it->first], it->second.symtab);
		// generator.clear_type_name();
	}

	cout << generator.get_format_strings();
	// cout << "here?";
	for (const auto& fun_code : code){
		cout << "\t.text\n" 
				 << "\t.globl " << fun_code.first << "\n"
				 << "\t.type  " << fun_code.first << ", @function\n"
				 << fun_code.first << ":\n";
		cout << "\tpushl %ebp\n"
			 << "\tmovl %esp, %ebp\n";
		int min_offset = 0;
		for (const auto& entry : gstfun.entries[fun_code.first].symtab->entries){
			if (entry.second.scope == "local")
				min_offset = std::min(min_offset, entry.second.offset);
		}
		if (min_offset)
			cout << "\tsubl $"+std::to_string(-min_offset)+", %esp\n";
		for (const auto& instr : fun_code.second){
			cout << (instr.type == STR ? "" : "\t") << generator.get_code_from_instr(instr) << "\n";
		}
		if (fun_code.second.back().type != RET){
			cout << "\tleave" << "\n";
			cout << "\tret" << "\n";
		}
 		cout << "\t.size "+fun_code.first+", .-"+fun_code.first+"\n";
	}

	exit(0);
}
