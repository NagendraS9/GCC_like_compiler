#include "codegen.hh"

std::string CodeGen :: get_format_strings() const {
    std::string code = "";
    for (const auto& format_str : format_strings){
        code += "\t.section .rodata\n";
        code += format_str.second + ":\n";
        code += "\t.string " + format_str.first + "\n";
    }
    return code;
}

std::string CodeGen :: get_code_from_instr(const Instr& instr) const {
    return instr.instr + " " + instr.op1 + (instr.op2 == "" ? "" : ", ") + instr.op2;
}

void CodeGen :: fill_stack(){
    rstack = std::stack<Regs>();
    rstack.push(EDI);
    rstack.push(ESI);
    rstack.push(EDX);
    rstack.push(ECX);
    rstack.push(EBX);
    rstack.push(EAX);
}

void CodeGen :: attribution(abstract_astnode* node){
    typeExp type = node->astnode_type;

    if (type == SEQ_ASTNODE){
        auto temp = (seq_astnode*) node;
        for (auto child : temp->children){
            attribution(child);
        }
        return;
    }
    if (type == ASSIGNS_ASTNODE){
        auto temp = (assignS_astnode*) node;
        attribution(temp->left);
        int left_label = temp->left->label;
        attribution(temp->right);
        int right_label = temp->right->label;
        temp->label = left_label == right_label ? left_label + 1 : std::max(left_label, right_label);
        return;
    }
    if (type == RETURN_ASTNODE){
        auto temp = (return_astnode*) node;
        attribution(temp->child);
        return;
    }
    if (type == PROCCALL_ASTNODE){
        auto temp = (proccall_astnode*) node;
        attribution(temp->fname);
        for (auto arg : temp->args){
            attribution(arg);
        }
        return;
    }
    if (type == IF_ASTNODE){
        auto temp = (if_astnode*) node;
        attribution(temp->cond);
        attribution(temp->true_stmt);
        attribution(temp->false_stmt);
        return;
    }
    if (type == WHILE_ASTNODE){
        auto temp = (while_astnode*) node;
        attribution(temp->cond);
        attribution(temp->stmt);
        return;
    }
    if (type == FOR_ASTNODE){
        auto temp = (for_astnode*) node;
        attribution(temp->init);
        attribution(temp->guard);
        attribution(temp->step);
        attribution(temp->stmt);
        return;
    }
    if (type == OP_BINARY_ASTNODE){
        auto temp = (op_binary_astnode*) node;
        attribution(temp->left);
        int left_label = temp->left->label;
        attribution(temp->right);
        int right_label = temp->right->label;
        temp->label = left_label == right_label ? left_label + 1 : std::max(left_label, right_label);
        return;
    }
    if (type == OP_UNARY_ASTNODE){
        auto temp = (op_unary_astnode*) node;
        attribution(temp->expr);
        temp->label = temp->expr->label;
        return;
    }
    if (type == ASSIGNE_ASTNODE){
        auto temp = (assignE_astnode*) node;
        attribution(temp->left);
        int left_label = temp->left->label;
        attribution(temp->right);
        int right_label = temp->right->label;
        temp->label = left_label == right_label ? left_label + 1 : std::max(left_label, right_label);
        return;
    }
    if (type == FUNCALL_ASTNODE){
        auto temp = (funcall_astnode*) node;
        attribution(temp->fname);
        int label = 1;
        for (auto arg : temp->args){
            attribution(arg);
            label = std::max(label, arg->label);
        }
        temp->label = label;
        return;
    }
    if (type == MEMBER_ASTNODE){
        auto temp = (member_astnode*) node;
        attribution(temp->expr);
        temp->label = temp->expr->label;
        return;
    }
    if (type == ARROW_ASTNODE){
        auto temp = (arrow_astnode*) node;
        attribution(temp->expr);
        node->label = temp->expr->label;
        return;
    }
    if (type == ARRAYREF_ASTNODE){
        auto temp = (arrayref_astnode*) node;
        attribution(temp->array);
        attribution(temp->idx);
        int l1 = temp->array->label;
        int l2 = temp->array->label;
        temp->label = l1 == l2 ? l1 + 1 : std::max(l1, l2);
        return;
    }
    if (type == IDENTIFIER_ASTNODE || type == INTCONST_ASTNODE || type == STRINGCONST_ASTNODE){
        node->label = 1;
        return;
    }
}

void CodeGen :: gencode(abstract_astnode* node, std::vector<Instr>& code, SymTab* st){
    // std::cout << "gencode " << node->astnode_type << "\n";
    typeExp type = node->astnode_type;
    if (type == EMPTY_ASTNODE){
        return;
    }
    if (type == SEQ_ASTNODE){
        // std::cout << "SEQ\n";
        auto temp = (seq_astnode*) node;
        for (auto child : temp->children){
            // std::cout << "child\n" << child->astnode_type << "\n";
            gencode(child, code, st);
            // std::cout << "done\n";

        }
        return;
    }
    if (type == RETURN_ASTNODE){
        auto temp = (return_astnode*) node;
        gencode_expr(temp->child, code, st, temp->child->type.t == STRUCT_TYPE);
        int offset = 12;
        for (const auto& entry : st->entries){
            if (entry.second.scope == "param"){
                offset += (entry.second.t.size);
            }
        }
        if (temp->child->type.t == STRUCT_TYPE){
            int sz = temp->child->type.size;
            for (int i=0;i<sz;i+=4){
                code.push_back({PUSHL, "pushl", get_reg_name(rstack.top())});
                code.push_back({MOVL, "movl", (i==0 ? "" : std::to_string(i))+"("+get_reg_name(rstack.top())+")", get_reg_name(rstack.top())});
                code.push_back({MOVL, "movl", get_reg_name(rstack.top()), std::to_string(offset+i)+"(%ebp)"});
                code.push_back({POPL, "popl", get_reg_name(rstack.top())});
            }
            // clean up struct temporaries
            if (add_offset)
                code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
            temp_offset += add_offset;
            add_offset = 0;
            code.push_back({LEAVE, "leave"});
            code.push_back({RET, "ret"});
            return;
        }
        // clean up struct temporaries
        if (add_offset)
            code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
        temp_offset += add_offset;
        add_offset = 0;
        code.push_back({MOVL, "movl", get_reg_name(rstack.top()), std::to_string(offset)+"(%ebp)"});
        code.push_back({LEAVE, "leave"});
        code.push_back({RET, "ret"});
        return;
    }
    if (type == PROCCALL_ASTNODE){
        // std::cout << "hmm\n";
        auto temp = (proccall_astnode*) node;
        if (temp->fname->id == "printf"){
            gencode_printf(temp, code, st);
             // free evaluated temporary
            if (add_offset)
                code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
            temp_offset += add_offset;
            add_offset = 0;
            return;
        } 
        auto fname = temp->fname->id;
        // AR construction 
        // save all regs except the reg on top of stack
        int size_params = 0;
        int regs_cnt = 0;
        // std::cout << "hmm2\n";
        Regs reg = rstack.top();
        if (reg != EAX)
            code.push_back({PUSHL, "pushl", "%eax"}), regs_to_pop.push_back(EAX);
        if (reg != EBX)
            code.push_back({PUSHL, "pushl", "%ebx"}), regs_to_pop.push_back(EBX);
        if (reg != ECX)
            code.push_back({PUSHL, "pushl", "%ecx"}), regs_to_pop.push_back(ECX);
        if (reg != EDX)
            code.push_back({PUSHL, "pushl", "%edx"}), regs_to_pop.push_back(EDX);
        if (reg != EDI)
            code.push_back({PUSHL, "pushl", "%edi"}), regs_to_pop.push_back(EDI);
        if (reg != ESI)
            code.push_back({PUSHL, "pushl", "%esi"}), regs_to_pop.push_back(ESI);

        temp_offset -= 4*regs_to_pop.size();
        int sz = 4;
        if (gst->entries[fname].t.t == STRUCT_TYPE){
            sz = gst->entries[gst->entries[fname].type_name].size;
            // std::cout << "sizeof(struct) " << sz << "\n";
        } 
        // return value 
        code.push_back({SUBL, "subl", "$"+std::to_string(sz), "%esp"});
        temp_offset -= sz;
        // params
        for (auto arg : temp->args){
            
            // need to copy struct to param
            if (arg->type.t == STRUCT_TYPE){
                // make space first then evaluate
                temp_offset -= arg->type.size;
                // copy all words to param local
                code.push_back({SUBL, "subl", "$"+std::to_string(arg->type.size), "%esp"});
                gencode_expr(arg, code, st, true);  // arg address
                
                // now copy struct to param
                for (int i=0;i<arg->type.size;i+=4){
                    code.push_back({PUSHL, "pushl", get_reg_name(rstack.top())});
                    code.push_back({MOVL, "movl", (i == 0 ? "" : std::to_string(i))+"("+get_reg_name(rstack.top())+")", get_reg_name(rstack.top())});
                    code.push_back({MOVL, "movl", get_reg_name(rstack.top()), std::to_string(temp_offset+i)+"(%ebp)"});
                    code.push_back({POPL, "popl", get_reg_name(rstack.top())});
                }
                // free evaluated temporary
                if (add_offset)
                    code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
                temp_offset += add_offset;
                add_offset = 0;
            } else {
                gencode_expr(arg, code, st, arg->type.t == ARRAY_TYPE);
                temp_offset -= 4;
                // free evaluated temporary
                if (add_offset)
                    code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
                temp_offset += add_offset;
                add_offset = 0;

                code.push_back({PUSHL, "pushl", get_reg_name(rstack.top())});
            }
            size_params += arg->type.t == ARRAY_TYPE ? 4 : arg->type.size;
            // std::cout << arg->type.t << "\n";
        }
        // std::cout << fname << " " << size_params << "\n";
        // Static link
        code.push_back({SUBL, "subl", "$4", "%esp"});
        temp_offset -= 4;   // SL 

        code.push_back({CALL, "call", fname});

        temp_offset += 4 + size_params + sz;
        code.push_back({ADDL, "addl", "$"+std::to_string(4+size_params+sz), "%esp"});
        
        if (reg != ESI)
            code.push_back({POPL, "popl", "%esi"});
        if (reg != EDI)
            code.push_back({POPL, "popl", "%edi"});
        if (reg != EDX)
            code.push_back({POPL, "popl", "%edx"});
        if (reg != ECX)
            code.push_back({POPL, "popl", "%ecx"});
        if (reg != EBX)
            code.push_back({POPL, "popl", "%ebx"});
        if (reg != EAX)
            code.push_back({POPL, "popl", "%eax"});
        temp_offset += 4*regs_to_pop.size();
        regs_to_pop.clear();
        return;
    }
    
    if (type == IF_ASTNODE){
        // std::cout << "if stmt\n";
        auto temp = (if_astnode*) node;
        auto label1 = get_label();
        auto label2 = get_label();
        gencode_expr(temp->cond, code, st);
        // clean up temporaries 
        if (add_offset)
            code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
        temp_offset += add_offset;
        add_offset = 0;

        code.push_back({CMPL, "cmpl", "$0", get_reg_name(rstack.top())});
        code.push_back({JE, "je", label1});
        gencode(temp->true_stmt, code, st);
        code.push_back({JMP, "jmp", label2});
        code.push_back({STR, label1 + ":"});    // false statement
        gencode(temp->false_stmt, code, st);
        code.push_back({STR, label2 + ":"});    // next statement
    }
    if (type == WHILE_ASTNODE){
        // std::cout << "while_astnode\n";
        auto temp = (while_astnode*) node;
        auto label1 = get_label();
        auto label2 = get_label();
        code.push_back({STR, label1 + ":"});
        gencode_expr(temp->cond, code, st);
        // clean up temporaries 
        if (add_offset)
            code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
        temp_offset += add_offset;
        add_offset = 0;

        code.push_back({CMPL, "cmpl", "$0", get_reg_name(rstack.top())});
        code.push_back({JE, "je", label2});
        gencode(temp->stmt, code, st);
        code.push_back({JMP, "jmp", label1});
        code.push_back({STR, label2 + ":"});
        // std::cout << "while_astnode done\n";
    }
    if (type == FOR_ASTNODE){
        auto temp = (for_astnode*) node;
        // init
        auto init = (assignE_astnode*) temp->init;
        gencode_assign(init->left, init->right, code, st);
        // clean up temporaries 
        if (add_offset)
            code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
        temp_offset += add_offset;
        add_offset = 0;

        auto guard = get_label();
        auto next = get_label();
        // guard 
        code.push_back({STR, guard + ":"});
        gencode_expr(temp->guard, code, st);
        // clean up temporaries 
        if (add_offset)
            code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
        temp_offset += add_offset;
        add_offset = 0;

        code.push_back({CMPL, "cmpl", "$0", get_reg_name(rstack.top())});
        code.push_back({JE, "je", next});
        gencode(temp->stmt, code, st);  // statement in for loop
        // step
        auto step = (assignE_astnode*) temp->step;
        gencode_assign(step->left, step->right, code, st);
        // clean up temporaries 
        if (add_offset)
            code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
        temp_offset += add_offset;
        add_offset = 0;

        code.push_back({JMP, "jmp", guard});  // jump back to guard
        code.push_back({STR, next + ":"});
    }
    if (type == ASSIGNS_ASTNODE){
        // std::cout << "ASSIGN\n";
        auto temp = (assignS_astnode*) node;
        gencode_assign(temp->left, temp->right, code, st);
        // clean up temporaries 
        if (add_offset)
            code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
        temp_offset += add_offset;
        add_offset = 0;
    }
}

void CodeGen :: gencode_expr(abstract_astnode* node, std::vector<Instr>& code, SymTab* st, bool addr){
    int i = (int) code.size();
    if (node->astnode_type == FUNCALL_ASTNODE){
        // std::cout << "hmm1\n";
        auto temp = (funcall_astnode*) node;
        auto fname = temp->fname->id;
        // AR construction 
        // save all regs except the reg on top of stack
        int size_params = 0;
        int regs_cnt = 0;
        // std::cout << "hmm2\n";
        Regs reg = rstack.top();
        if (reg != EAX)
            code.push_back({PUSHL, "pushl", "%eax"}), regs_to_pop.push_back(EAX), regs_cnt++;
        if (reg != EBX)
            code.push_back({PUSHL, "pushl", "%ebx"}), regs_to_pop.push_back(EBX), regs_cnt++;
        if (reg != ECX)
            code.push_back({PUSHL, "pushl", "%ecx"}), regs_to_pop.push_back(ECX), regs_cnt++;
        if (reg != EDX)
            code.push_back({PUSHL, "pushl", "%edx"}), regs_to_pop.push_back(EDX), regs_cnt++;
        if (reg != EDI)
            code.push_back({PUSHL, "pushl", "%edi"}), regs_to_pop.push_back(EDI), regs_cnt++;
        if (reg != ESI)
            code.push_back({PUSHL, "pushl", "%esi"}), regs_to_pop.push_back(ESI), regs_cnt++;

        temp_offset -= 4*regs_cnt;
        int sz = 4;
        if (gst->entries[fname].t.t == STRUCT_TYPE){
            sz = gst->entries[gst->entries[fname].type_name].size;
        } 
        // return value 
        code.push_back({SUBL, "subl", "$"+std::to_string(sz), "%esp"});
        temp_offset -= sz;
        // params
        for (auto arg : temp->args){
            
            // need to copy struct to param
            if (arg->type.t == STRUCT_TYPE){
                // make space for param
                temp_offset -= arg->type.size;
                // copy all words to param local
                code.push_back({SUBL, "subl", "$"+std::to_string(arg->type.size), "%esp"});
                gencode_expr(arg, code, st, true);  // arg address
                for (int i=0;i<arg->type.size;i+=4){
                    code.push_back({PUSHL, "pushl", get_reg_name(rstack.top())});
                    code.push_back({MOVL, "movl", (i == 0 ? "" : std::to_string(i))+"("+get_reg_name(rstack.top())+")", get_reg_name(rstack.top())});
                    code.push_back({MOVL, "movl", get_reg_name(rstack.top()), std::to_string(temp_offset+i)+"(%ebp)"});
                    code.push_back({POPL, "popl", get_reg_name(rstack.top())});
                }
                // clean up temporaries (can't mess with function params)
                if (add_offset)
                    code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
                temp_offset += add_offset;
                add_offset = 0;

            } else {
                gencode_expr(arg, code, st, arg->type.t == ARRAY_TYPE);
                // free evaluated temporary
                if (add_offset)
                    code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
                temp_offset += add_offset;
                add_offset = 0;
                temp_offset -= 4;
                code.push_back({PUSHL, "pushl", get_reg_name(rstack.top())});
            }
            size_params += arg->type.t == ARRAY_TYPE ? 4 : arg->type.size;
            // std::cout << arg->type.t << " " << arg->type.size << "\n";
        }
        // Static link
        code.push_back({SUBL, "subl", "$4", "%esp"});
        temp_offset -= 4;   // SL 
        // std::cout << fname << " " << temp_offset << "\n";
 
        code.push_back({CALL, "call", fname});

        temp_offset += 4 + size_params;
        code.push_back({ADDL, "addl", "$"+std::to_string(4+size_params), "%esp"});
        
        // std::cout << fname << " " << temp_offset << "\n";
        
        if (temp->type.t == STRUCT_TYPE){
            code.push_back({LEAL, "leal", std::to_string(temp_offset)+"(%ebp)", get_reg_name(reg)});
            // restore registers
            int n = regs_to_pop.size();
            add_offset = sz;
            for (int i=n-1;i>=0;i--){
                if (regs_to_pop[i] == EAX)
                    code.push_back({MOVL, "movl", std::to_string(temp_offset+add_offset+4*(n-i-1))+"(%ebp)", "%eax"});
                if (regs_to_pop[i] == EBX)
                    code.push_back({MOVL, "movl", std::to_string(temp_offset+add_offset+4*(n-i-1))+"(%ebp)", "%ebx"});
                if (regs_to_pop[i] == ECX)
                    code.push_back({MOVL, "movl", std::to_string(temp_offset+add_offset+4*(n-i-1))+"(%ebp)", "%ecx"});
                if (regs_to_pop[i] == EDX)
                    code.push_back({MOVL, "movl", std::to_string(temp_offset+add_offset+4*(n-i-1))+"(%ebp)", "%edx"});
                if (regs_to_pop[i] == EDI)
                    code.push_back({MOVL, "movl", std::to_string(temp_offset+add_offset+4*(n-i-1))+"(%ebp)", "%edi"});
                if (regs_to_pop[i] == ESI)
                    code.push_back({MOVL, "movl", std::to_string(temp_offset+add_offset+4*(n-i-1))+"(%ebp)", "%esi"});
            }
            add_offset += 4*n;
            regs_to_pop.clear();
            return;
        }
        code.push_back({POPL, "popl", get_reg_name(reg)});
        if (reg != ESI)
            code.push_back({POPL, "popl", "%esi"});
        if (reg != EDI)
            code.push_back({POPL, "popl", "%edi"});
        if (reg != EDX)
            code.push_back({POPL, "popl", "%edx"});
        if (reg != ECX)
            code.push_back({POPL, "popl", "%ecx"});
        if (reg != EBX)
            code.push_back({POPL, "popl", "%ebx"});
        if (reg != EAX)
            code.push_back({POPL, "popl", "%eax"});
        temp_offset += 4*regs_cnt;
        temp_offset += sz;
        regs_to_pop.clear();
        return;
    }
    // field access 
    if (node->astnode_type == MEMBER_ASTNODE){
        auto temp = (member_astnode*) node;
        auto member = temp->identifier->id;
        gencode_expr(temp->expr, code, st, true);   // address of struct expr
        int offset = 0;
        for (const auto& entry : gst->entries[temp->struct_name].symtab->entries){
            if (entry.first == member){
                offset = entry.second.offset;
            }
        }
        if (offset)
            code.push_back({ADDL, "addl" , "$"+std::to_string(offset), get_reg_name(rstack.top())});
        if (!addr)
            code.push_back({MOVL, "movl", "("+get_reg_name(rstack.top())+")", get_reg_name(rstack.top())});
        // if (temp->expr->astnode_type == FUNCALL_ASTNODE){
        //     int n = regs_to_pop.size();
        //     temp_offset += add_offset;
        //     code.push_back({ADDL, "addl", "$"+std::to_string(add_offset+4*n), "%esp"});
        //     temp_offset += 4*n;
        //     regs_to_pop.clear();
        //     add_offset = 0;
        // }
        // std::cout << regs_to_pop.size() << "\n";
        return;
    }
    if (node->astnode_type == ARROW_ASTNODE){
        auto temp = (arrow_astnode*) node;
        auto member = temp->identifier->id;
        gencode_expr(temp->expr, code, st);   // address of struct expr
        int offset = 0;
        for (const auto& entry : gst->entries[temp->struct_name].symtab->entries){
            if (entry.first == member){
                offset = entry.second.offset;
            }
        }
        if (offset)
            code.push_back({ADDL, "addl" , "$"+std::to_string(offset), get_reg_name(rstack.top())});
        if (!addr)
            code.push_back({MOVL, "movl", "("+get_reg_name(rstack.top())+")", get_reg_name(rstack.top())});
        if (temp->expr->astnode_type == FUNCALL_ASTNODE){
            int n = regs_to_pop.size();
            temp_offset += add_offset;
            code.push_back({ADDL, "addl", "$"+std::to_string(add_offset+4*n), "%esp"});
            temp_offset += 4*n;
            regs_to_pop.clear();
            add_offset = 0;
        }
        // std::cout << regs_to_pop.size() << "\n";
        return;
    }
    if (node->astnode_type == ARRAYREF_ASTNODE){
        auto temp = (arrayref_astnode*) node;
        // first generate addr of array
        // we'll do addr(array) + idx*sizeof(element(array))
        if (temp->idx->label < (int)rstack.size()){
            if (temp->array->type.t == PTR_TYPE){
                auto deref = new op_unary_astnode("DEREF", temp->array, (*temp->array->type.element_type));
                deref->label =  temp->array->label;
                gencode_expr(deref, code, st, true);
                delete deref;
            } else {
                gencode_expr(temp->array, code, st, true);
            }
            Regs reg = rstack.top();
            rstack.pop();
            gencode_expr(temp->idx, code, st);
            code.push_back({IMULL, "imull", "$"+std::to_string(temp->type.size), get_reg_name(rstack.top())});
            code.push_back({ADDL, "addl", get_reg_name(rstack.top()), get_reg_name(reg)});
            if (!addr && temp->type.t != ARRAY_TYPE)
                code.push_back({MOVL, "movl", "("+get_reg_name(reg)+")", get_reg_name(reg)});
            rstack.push(reg);
            return;
        }
        if (temp->array->label < (int)rstack.size()){
            swap(rstack);
            gencode_expr(temp->idx, code, st);
            Regs reg = rstack.top();
            rstack.pop();
            if (temp->array->type.t == PTR_TYPE){
                auto deref = new op_unary_astnode("DEREF", temp->array, (*temp->array->type.element_type));
                deref->label =  temp->array->label;
                gencode_expr(deref, code, st, true);
                delete deref;
            } else {
                gencode_expr(temp->array, code, st, true);
            }
            code.push_back({IMULL, "imull", "$"+std::to_string(temp->type.size), get_reg_name(reg)});
            code.push_back({ADDL, "addl", get_reg_name(reg), get_reg_name(rstack.top())});
            if (!addr && temp->type.t != ARRAY_TYPE)
                code.push_back({MOVL, "movl", "("+get_reg_name(rstack.top())+")", get_reg_name(rstack.top())});
            rstack.push(reg);
            swap(rstack);
            return;
        }
        gencode_expr(temp->idx, code, st);
        temp_offset -= 4;
        code.push_back({SUBL, "subl", "$4", "%esp"});
        code.push_back({MOVL, "movl", get_reg_name(rstack.top()), std::to_string(temp_offset)+"(%ebp)"});
        if (temp->array->type.t == PTR_TYPE){
            auto deref = new op_unary_astnode("DEREF", temp->array, (*temp->array->type.element_type));
            deref->label =  temp->array->label;
            gencode_expr(deref, code, st, true);
            delete deref;
        } else {
            gencode_expr(temp->array, code, st, true);
        }
        Regs reg = rstack.top();
        rstack.pop();
        code.push_back({MOVL, "movl", std::to_string(temp_offset)+"(%ebp)", get_reg_name(rstack.top())});
        code.push_back({IMULL, "imull", "$"+std::to_string(temp->type.size), get_reg_name(rstack.top())});
        code.push_back({ADDL, "addl", get_reg_name(rstack.top()), get_reg_name(reg)});
        if (!addr && temp->type.t != ARRAY_TYPE)
            code.push_back({MOVL, "movl", "("+get_reg_name(reg)+")", get_reg_name(reg)});
        code.push_back({ADDL, "addl", "$4", "%esp"});
        rstack.push(reg);
        temp_offset += 4;
        return;
    }
    if (node->astnode_type == IDENTIFIER_ASTNODE){
        auto temp = (identifier_astnode*) node;
        int offset = st->entries[temp->id].offset;
        code.push_back({addr || temp->type.t == ARRAY_TYPE ? LEAL : MOVL, addr || temp->type.t == ARRAY_TYPE ? "leal" : "movl", std::to_string(offset)+"(%ebp)", get_reg_name(rstack.top())});
        return;
    }
    if (node->astnode_type == INTCONST_ASTNODE){
        auto temp = (intconst_astnode*) node;
        code.push_back({MOVL, "movl", "$"+std::to_string(temp->val), get_reg_name(rstack.top())});
        return;
    }
    if (node->astnode_type == OP_UNARY_ASTNODE){
        auto temp = (op_unary_astnode*) node;
        if (temp->op == "UMINUS"){
            gencode_expr(temp->expr, code, st);
            code.push_back({NEGL, "negl", get_reg_name(rstack.top())});
            // clean up temporaries 
            if (add_offset)
                code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
            temp_offset += add_offset;
            add_offset = 0;
            return;
        }
        if (temp->op == "NOT"){
            gencode_bool_expr(temp, code, st);
            // clean up temporaries 
            if (add_offset)
                code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
            temp_offset += add_offset;
            add_offset = 0;
            return;
        }
        if (temp->op == "ADDRESS"){
            gencode_expr(temp->expr, code, st, true);
            // clean up temporaries 
            if (add_offset)
                code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
            temp_offset += add_offset;
            add_offset = 0;
            return;
        }
        if (temp->op == "PP"){
            // std::cout << "PP\n";
            auto one = new intconst_astnode(1, createtype(INT_TYPE));
            one->label = 1;
            auto plus = new op_binary_astnode("PLUS_INT", temp->expr, one, temp->type);
            plus->label = temp->expr->label == 1 ? 2 : temp->expr->label;

            gencode_assign(temp->expr, plus, code, st);
            // set value of this expr to original value
            auto sub = new op_binary_astnode("MINUS_INT", temp->expr, one, temp->type);
            one->label = temp->expr->label == 1 ? 2 : temp->expr->label;
            gencode_expr(sub, code, st);

            delete one;
            delete plus;
            delete sub;
            // std::cout << "PP done\n";
            return;
        }
        if (temp->op == "DEREF"){
            gencode_expr(temp->expr, code, st, temp->expr->type.t == ARRAY_TYPE);
            // clean up temporaries 
            if (add_offset)
                code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
            temp_offset += add_offset;
            add_offset = 0;
            if ((!addr && temp->expr->type.t != ARRAY_TYPE && temp->type.t != ARRAY_TYPE) 
                || (!addr && temp->expr->type.t == ARRAY_TYPE && temp->type.t != ARRAY_TYPE)
            ){
                code.push_back({MOVL, "movl", "("+get_reg_name(rstack.top())+")", get_reg_name(rstack.top())});
            }
            // if (temp->expr->type.t == ARRAY_TYPE){

            // }
            return;
        }
    }
    if (node->astnode_type == OP_BINARY_ASTNODE){
        auto temp = (op_binary_astnode*) node;
        if (temp->op == "AND_OP" || temp->op == "OR_OP"){
            gencode_bool_expr(temp, code, st);
            return;
        }
        if (temp->right->astnode_type == IDENTIFIER_ASTNODE && temp->left->type.t != PTR_TYPE && temp->right->type.t != PTR_TYPE && temp->left->type.t != ARRAY_TYPE && temp->right->type.t != ARRAY_TYPE){
            gencode_expr(temp->left, code, st);
            // clean up temporaries 
            if (add_offset)
                code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
            temp_offset += add_offset;
            add_offset = 0;
            int offset = st->entries[((identifier_astnode*)temp->right)->id].offset;
            if (temp->op == "PLUS_INT"){
                code.push_back({ADDL, "addl", std::to_string(offset)+"(%ebp)", get_reg_name(rstack.top())});
                return;
            }
            if (temp->op == "MINUS_INT"){
                code.push_back({SUBL, "subl", std::to_string(offset)+"(%ebp)", get_reg_name(rstack.top())});
                return;
            }
            if (temp->op == "MULT_INT"){
                code.push_back({IMULL, "imull", std::to_string(offset)+"(%ebp)", get_reg_name(rstack.top())});
                return;
            }
            if (temp->op == "DIV_INT"){
                if (rstack.top() != EAX && rstack.top() != EDX){
                    // save %edx & %eax
                    code.push_back({PUSHL, "pushl", "%edx"});
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({MOVL, "movl", get_reg_name(rstack.top()), "%eax"});
                    code.push_back({CLTD, "cltd"});
                    code.push_back({IDIVL, "idivl", std::to_string(offset)+"(%ebp)"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                    code.push_back({POPL, "popl", "%eax"});
                    code.push_back({POPL, "popl", "%edx"});
                    return;
                } 
                if (rstack.top() == EAX){
                    code.push_back({PUSHL, "pushl", "%edx"});
                    code.push_back({CLTD, "cltd"});
                    code.push_back({IDIVL, "idivl", std::to_string(offset)+"(%ebp)"});
                    code.push_back({POPL, "popl", "%edx"});
                    return;
                }
                code.push_back({PUSHL, "pushl", "%eax"});
                code.push_back({MOVL, "movl", get_reg_name(rstack.top()), "%eax"});
                code.push_back({CLTD, "cltd"});
                code.push_back({IDIVL, "idivl", std::to_string(offset)+"(%ebp)"});
                code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                code.push_back({POPL, "popl", "%eax"});
                return;
            }
            // ==
            if (temp->op == "EQ_OP_INT"){
                if (rstack.top() != EAX){
                    // save %eax
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), std::to_string(offset)+"(%ebp)"});
                    code.push_back({SETE, "sete", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                    code.push_back({POPL, "popl", "%eax"});
                    return;
                }
                code.push_back({CMPL, "cmpl", "%eax", std::to_string(offset)+"(%ebp)"});
                code.push_back({SETE, "sete", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                return;
            }
            // != 
            if (temp->op == "NE_OP_INT"){
                if (rstack.top() != EAX){
                    // save %eax
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), std::to_string(offset)+"(%ebp)"});
                    code.push_back({SETNE, "setne", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                    code.push_back({POPL, "popl", "%eax"});
                    return;
                }
                code.push_back({CMPL, "cmpl", "%eax", std::to_string(offset)+"(%ebp)"});
                code.push_back({SETNE, "setne", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                return;
            }
            // < 
            if (temp->op == "LT_OP_INT"){
                if (rstack.top() != EAX){
                    // save %eax
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), std::to_string(offset)+"(%ebp)"});
                    code.push_back({SETG, "setg", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                    code.push_back({POPL, "popl", "%eax"});
                    return;
                }
                code.push_back({CMPL, "cmpl", "%eax", std::to_string(offset)+"(%ebp)"});
                code.push_back({SETG, "setg", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                return;
            }
            // >
            if (temp->op == "GT_OP_INT"){
                if (rstack.top() != EAX){
                    // save %eax
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), std::to_string(offset)+"(%ebp)"});
                    code.push_back({SETL, "setl", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                    code.push_back({POPL, "popl", "%eax"});
                    return;
                }
                code.push_back({CMPL, "cmpl", "%eax", std::to_string(offset)+"(%ebp)"});
                code.push_back({SETL, "setl", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                return;
            }
            // <=
            if (temp->op == "LE_OP_INT"){
                if (rstack.top() != EAX){
                    // save %eax
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), std::to_string(offset)+"(%ebp)"});
                    code.push_back({SETGE, "setge", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                    code.push_back({POPL, "popl", "%eax"});
                    return;
                }
                code.push_back({CMPL, "cmpl", "%eax", std::to_string(offset)+"(%ebp)"});
                code.push_back({SETGE, "setge", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                return;
            }
            // >=
            if (temp->op == "GE_OP_INT"){
                if (rstack.top() != EAX){
                    // save %eax
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), std::to_string(offset)+"(%ebp)"});
                    code.push_back({SETLE, "setle", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                    code.push_back({POPL, "popl", "%eax"});
                    return;
                }
                code.push_back({CMPL, "cmpl", "%eax", std::to_string(offset)+"(%ebp)"});
                code.push_back({SETLE, "setle", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                return;
            }
            
        }
        if (temp->right->astnode_type == INTCONST_ASTNODE && temp->op != "DIV_INT"){
            gencode_expr(temp->left, code, st, temp->left->type.t == ARRAY_TYPE);
            // clean up temporaries 
            if (add_offset)
                code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
            temp_offset += add_offset;
            add_offset = 0;
            std::string val = std::to_string((temp->left->type.t == PTR_TYPE || temp->left->type.t == ARRAY_TYPE ? temp->left->type.element_type->size : 1)*((intconst_astnode*)temp->right)->val);
            if (temp->op == "PLUS_INT"){
                code.push_back({ADDL, "addl", "$"+val, get_reg_name(rstack.top())});
                return;
            }
            if (temp->op == "MINUS_INT"){
                code.push_back({SUBL, "subl", "$"+val, get_reg_name(rstack.top())});
                return;
            }
            if (temp->op == "MULT_INT"){
                code.push_back({IMULL, "imull", "$"+val, get_reg_name(rstack.top())});
                return;
            }
            // ==
            if (temp->op == "EQ_OP_INT"){
                if (rstack.top() != EAX){
                    // save %eax
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", "$"+val, get_reg_name(rstack.top())});
                    code.push_back({SETE, "sete", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                    code.push_back({POPL, "popl", "%eax"});
                    return;
                }
                code.push_back({CMPL, "cmpl", "$"+val, "%eax"});
                code.push_back({SETE, "sete", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                return;
            }
            // !=
            if (temp->op == "NE_OP_INT"){
                if (rstack.top() != EAX){
                    // save %eax
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl",  "$"+val, get_reg_name(rstack.top())});
                    code.push_back({SETNE, "setne", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                    code.push_back({POPL, "popl", "%eax"});
                    return;
                }
                code.push_back({CMPL, "cmpl", "$"+val, "%eax"});
                code.push_back({SETNE, "setne", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                return;
            }
            // <
            if (temp->op == "LT_OP_INT"){
                if (rstack.top() != EAX){
                    // save %eax
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", "$"+val, get_reg_name(rstack.top())});
                    code.push_back({SETL, "setl", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                    code.push_back({POPL, "popl", "%eax"});
                    return;
                }
                code.push_back({CMPL, "cmpl", "$"+val, "%eax"});
                code.push_back({SETL, "setl", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                return;
            }
            // >
            if (temp->op == "GT_OP_INT"){
                if (rstack.top() != EAX){
                    // save %eax
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", "$"+val, get_reg_name(rstack.top())});
                    code.push_back({SETG, "setg", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                    code.push_back({POPL, "popl", "%eax"});
                    return;
                }
                code.push_back({CMPL, "cmpl", "$"+val, "%eax"});
                code.push_back({SETG, "setg", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                return;
            }
            // <=
            if (temp->op == "LE_OP_INT"){
                if (rstack.top() != EAX){
                    // save %eax
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", "$"+val, get_reg_name(rstack.top())});
                    code.push_back({SETLE, "setle", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                    code.push_back({POPL, "popl", "%eax"});
                    return;
                }
                code.push_back({CMPL, "cmpl", "$"+val, "%eax"});
                code.push_back({SETLE, "setle", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                return;
            }
            // >=
            if (temp->op == "GE_OP_INT"){
                if (rstack.top() != EAX){
                    // save %eax
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", "$"+val, get_reg_name(rstack.top())});
                    code.push_back({SETGE, "setge", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                    code.push_back({POPL, "popl", "%eax"});
                    return;
                }
                code.push_back({CMPL, "cmpl", "$"+val, "%eax"});
                code.push_back({SETGE, "setge", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                return;
            }
        }
        if (temp->right->label < (int)rstack.size()){
            gencode_expr(temp->left, code, st, temp->left->type.t == ARRAY_TYPE);
            // clean up temporaries 
            if (add_offset)
                code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
            temp_offset += add_offset;
            add_offset = 0;
            Regs reg = rstack.top();
            rstack.pop();
            gencode_expr(temp->right, code, st, temp->right->type.t == ARRAY_TYPE);
            // clean up temporaries 
            if (add_offset)
                code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
            temp_offset += add_offset;
            add_offset = 0;
            if (temp->op == "PLUS_INT"){
                if (temp->right->type.t == PTR_TYPE || temp->right->type.t == ARRAY_TYPE){
                    code.push_back({IMULL, "imull", "$"+std::to_string(temp->right->type.element_type->size), get_reg_name(reg)});
                } else if (temp->left->type.t == PTR_TYPE || temp->left->type.t == ARRAY_TYPE){
                    code.push_back({IMULL, "imull", "$"+std::to_string(temp->left->type.element_type->size), get_reg_name(rstack.top())});
                }
                code.push_back({ADDL, "addl", get_reg_name(rstack.top()), get_reg_name(reg)});
                rstack.push(reg);
                return;
            }
            if (temp->op == "MINUS_INT"){
                if (temp->left->type.t == PTR_TYPE || temp->left->type.t == ARRAY_TYPE)
                    code.push_back({IMULL, "imull", "$"+std::to_string(temp->left->type.element_type->size), get_reg_name(rstack.top())});
                
                code.push_back({SUBL, "subl", get_reg_name(rstack.top()), get_reg_name(reg)});
                rstack.push(reg);
                return;
            }
            if (temp->op == "MULT_INT"){
                code.push_back({IMULL, "imull", get_reg_name(rstack.top()), get_reg_name(reg)});
                rstack.push(reg);
                return;
            }
            if (temp->op == "DIV_INT"){
                // std::cout << "962\n";
                if (reg != EDX)
                    code.push_back({PUSHL, "pushl", "%edx"}), temp_offset -= 4;
                if (reg != EAX)
                    code.push_back({PUSHL, "pushl", "%eax"}), temp_offset -= 4;
                temp_offset -= 4;
                code.push_back({SUBL, "subl", "$4", "%esp"});
                code.push_back({MOVL, "movl", get_reg_name(rstack.top()), std::to_string(temp_offset)+"(%ebp)"});
                if (reg != EAX)
                    code.push_back({MOVL, "movl", get_reg_name(reg), "%eax"});
                code.push_back({CLTD, "cltd"});
                code.push_back({IDIVL, "idivl", std::to_string(temp_offset)+"(%ebp)"});
                if (reg != EAX)
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(reg)});
                code.push_back({ADDL, "addl", "$4", "%esp"});
                temp_offset += 4;
                if (reg != EAX)
                    code.push_back({POPL, "popl", "%eax"}), temp_offset += 4;
                if (reg != EDX)
                    code.push_back({POPL, "popl", "%edx"}), temp_offset += 4;
                rstack.push(reg);
                return;
            }
            // ==
            if (temp->op == "EQ_OP_INT"){
                if (reg != EAX){
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", get_reg_name(reg), get_reg_name(rstack.top())});
                    code.push_back({SETE, "sete", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(reg)});
                    code.push_back({POPL, "popl", "%eax"});
                    rstack.push(reg);
                    return;
                }
                code.push_back({CMPL, "cmpl", get_reg_name(reg), get_reg_name(rstack.top())});
                code.push_back({SETE, "sete", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                rstack.push(reg);
                return;
            }
            // != 
            if (temp->op == "NE_OP_INT"){
                if (reg != EAX){
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", get_reg_name(reg), get_reg_name(rstack.top())});
                    code.push_back({SETNE, "setne", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(reg)});
                    code.push_back({POPL, "popl", "%eax"});
                    rstack.push(reg);
                    return;
                }
                code.push_back({CMPL, "cmpl", get_reg_name(reg), get_reg_name(rstack.top())});
                code.push_back({SETNE, "setne", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                rstack.push(reg);
                return;
            }
            // <
            if (temp->op == "LT_OP_INT"){
                if (reg != EAX){
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", get_reg_name(reg), get_reg_name(rstack.top())});
                    code.push_back({SETG, "setg", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(reg)});
                    code.push_back({POPL, "popl", "%eax"});
                    rstack.push(reg);
                    return;
                }
                code.push_back({CMPL, "cmpl", get_reg_name(reg), get_reg_name(rstack.top())});
                code.push_back({SETG, "setg", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                rstack.push(reg);
                return;
            }
            // >
            if (temp->op == "GT_OP_INT"){
                if (reg != EAX){
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", get_reg_name(reg), get_reg_name(rstack.top())});
                    code.push_back({SETL, "setl", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(reg)});
                    code.push_back({POPL, "popl", "%eax"});
                    rstack.push(reg);
                    return;
                }
                code.push_back({CMPL, "cmpl", get_reg_name(reg), get_reg_name(rstack.top())});
                code.push_back({SETL, "setl", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                rstack.push(reg);
                return;
            }
            // <= 
            if (temp->op == "LE_OP_INT"){
                if (reg != EAX){
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", get_reg_name(reg), get_reg_name(rstack.top())});
                    code.push_back({SETGE, "setge", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(reg)});
                    code.push_back({POPL, "popl", "%eax"});
                    rstack.push(reg);
                    return;
                }
                code.push_back({CMPL, "cmpl", get_reg_name(reg), get_reg_name(rstack.top())});
                code.push_back({SETGE, "setge", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                rstack.push(reg);
                return;
            }
            // >=
            if (temp->op == "GE_OP_INT"){
                if (reg != EAX){
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", get_reg_name(reg), get_reg_name(rstack.top())});
                    code.push_back({SETLE, "setle", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(reg)});
                    code.push_back({POPL, "popl", "%eax"});
                    rstack.push(reg);
                    return;
                }
                code.push_back({CMPL, "cmpl", get_reg_name(reg), get_reg_name(rstack.top())});
                code.push_back({SETLE, "setle", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                rstack.push(reg);
                return;
            }
        }
        if (temp->left->label < (int)rstack.size()){
            swap(rstack);
            gencode_expr(temp->right, code, st, temp->right->type.t == ARRAY_TYPE);
            // clean up temporaries 
            if (add_offset)
                code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
            temp_offset += add_offset;
            add_offset = 0;

            Regs reg = rstack.top();
            rstack.pop();
            gencode_expr(temp->left, code, st, temp->left->type.t == ARRAY_TYPE);
            // clean up temporaries 
            if (add_offset)
                code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
            temp_offset += add_offset;
            add_offset = 0;
           
            if (temp->op == "PLUS_INT"){
                if (temp->right->type.t == PTR_TYPE || temp->right->type.t == ARRAY_TYPE){
                    code.push_back({IMULL, "imull", "$"+std::to_string(temp->right->type.element_type->size), get_reg_name(rstack.top())});
                } else if (temp->left->type.t == PTR_TYPE || temp->left->type.t == ARRAY_TYPE){
                    code.push_back({IMULL, "imull", "$"+std::to_string(temp->left->type.element_type->size), get_reg_name(reg)});
                }
                code.push_back({ADDL, "addl", get_reg_name(reg), get_reg_name(rstack.top())});
                rstack.push(reg);
                swap(rstack);
                return;
            }
            if (temp->op == "MINUS_INT"){
                if (temp->left->type.t == PTR_TYPE || temp->left->type.t == ARRAY_TYPE){
                    code.push_back({IMULL, "imull", "$"+std::to_string(temp->left->type.element_type->size), get_reg_name(reg)});
                }
                code.push_back({SUBL, "subl", get_reg_name(reg), get_reg_name(rstack.top())});
                rstack.push(reg);
                swap(rstack);
                return;
            }
            if (temp->op == "MULT_INT"){
                code.push_back({IMULL, "imull", get_reg_name(reg), get_reg_name(rstack.top())});
                rstack.push(reg);
                swap(rstack);
                return;
            }
            if (temp->op == "DIV_INT"){
                // std::cout << "1139" << "\n";
                if (rstack.top() != EDX)
                    code.push_back({PUSHL, "pushl", "%edx"}), temp_offset -= 4;
                if (rstack.top() != EAX)
                    code.push_back({PUSHL, "pushl", "%eax"}), temp_offset -= 4;
                temp_offset -= 4;
                code.push_back({SUBL, "subl", "$4", "%esp"});
                code.push_back({MOVL, "movl", get_reg_name(reg), std::to_string(temp_offset)+"(%ebp)"});
                if (rstack.top() != EAX)
                    code.push_back({MOVL, "movl", get_reg_name(rstack.top()), "%eax"});
                code.push_back({CLTD, "cltd"});
                code.push_back({IDIVL, "idivl", std::to_string(temp_offset)+"(%ebp)"});
                if (rstack.top() != EAX)
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                code.push_back({ADDL, "addl", "$4", "%esp"});
                temp_offset += 4;
                if (rstack.top() != EAX)
                    code.push_back({POPL, "popl", "%eax"}), temp_offset += 4;
                if (rstack.top() != EDX)
                    code.push_back({POPL, "popl", "%edx"}), temp_offset += 4;
                rstack.push(reg);
                swap(rstack);
                return;
            }
            // == 
            if (temp->op == "EQ_OP_INT"){
                if (rstack.top() != EAX){
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), get_reg_name(reg)});
                    code.push_back({SETE, "sete", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                    code.push_back({POPL, "popl", "%eax"});
                    rstack.push(reg);
                    swap(rstack);
                    return;
                }
                code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), get_reg_name(reg)});
                code.push_back({SETE, "sete", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                rstack.push(reg);
                swap(rstack);
                return;
            }
            // != 
            if (temp->op == "NE_OP_INT"){
                if (rstack.top() != EAX){
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), get_reg_name(reg)});
                    code.push_back({SETNE, "setne", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                    code.push_back({POPL, "popl", "%eax"});
                    rstack.push(reg);
                    swap(rstack);
                    return;
                }
                code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), get_reg_name(reg)});
                code.push_back({SETNE, "setne", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                rstack.push(reg);
                swap(rstack);
                return;
            }
            // < 
            if (temp->op == "LT_OP_INT"){
                if (rstack.top() != EAX){
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), get_reg_name(reg)});
                    code.push_back({SETG, "setg", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                    code.push_back({POPL, "popl", "%eax"});
                    rstack.push(reg);
                    swap(rstack);
                    return;
                }
                code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), get_reg_name(reg)});
                code.push_back({SETG, "setg", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                rstack.push(reg);
                swap(rstack);
                return;
            }
            // >
            if (temp->op == "GT_OP_INT"){
                if (rstack.top() != EAX){
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), get_reg_name(reg)});
                    code.push_back({SETL, "setl", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                    code.push_back({POPL, "popl", "%eax"});
                    rstack.push(reg);
                    swap(rstack);
                    return;
                }
                code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), get_reg_name(reg)});
                code.push_back({SETL, "setl", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                rstack.push(reg);
                swap(rstack);
                return;
            }
            // <= 
            if (temp->op == "LE_OP_INT"){
                if (rstack.top() != EAX){
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), get_reg_name(reg)});
                    code.push_back({SETGE, "setge", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                    code.push_back({POPL, "popl", "%eax"});
                    rstack.push(reg);
                    swap(rstack);
                    return;
                }
                code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), get_reg_name(reg)});
                code.push_back({SETGE, "setge", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                rstack.push(reg);
                swap(rstack);
                return;
            }
            // >=
            if (temp->op == "GE_OP_INT"){
                if (rstack.top() != EAX){
                    code.push_back({PUSHL, "pushl", "%eax"});
                    code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), get_reg_name(reg)});
                    code.push_back({SETLE, "setle", "%al"});
                    code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                    code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                    code.push_back({POPL, "popl", "%eax"});
                    rstack.push(reg);
                    swap(rstack);
                    return;
                }
                code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), get_reg_name(reg)});
                code.push_back({SETLE, "setle", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                rstack.push(reg);
                swap(rstack);
                return;
            }
        }
        gencode_expr(temp->right, code, st, temp->right->type.t == ARRAY_TYPE);
        // clean up temporaries 
        if (add_offset)
            code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
        temp_offset += add_offset;
        add_offset = 0;

        temp_offset -= 4;
        code.push_back({SUBL, "subl", "$4", "%esp"});
        code.push_back({MOVL, "movl", get_reg_name(rstack.top()), std::to_string(temp_offset)+"(%ebp)"});
        gencode_expr(temp->left, code, st, temp->right->type.t == ARRAY_TYPE);
        // clean up temporaries 
        if (add_offset)
            code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
        temp_offset += add_offset;
        add_offset = 0;
        if (temp->op == "PLUS_INT"){
            Regs reg = rstack.top();
            rstack.pop();
            code.push_back({MOVL, "movl", std::to_string(temp_offset)+"(%ebp)", get_reg_name(rstack.top())});
            if (temp->left->type.t == PTR_TYPE || temp->left->type.t == ARRAY_TYPE){
                code.push_back({IMULL, "imull", "$"+std::to_string(temp->left->type.element_type->size), get_reg_name(rstack.top())});
            } else if (temp->right->type.t == PTR_TYPE || temp->right->type.t == ARRAY_TYPE){
                code.push_back({IMULL, "imull", "$"+std::to_string(temp->right->type.element_type->size), get_reg_name(reg)});
            }
            code.push_back({ADDL, "addl", get_reg_name(rstack.top()), get_reg_name(reg)});
            code.push_back({ADDL, "addl", "$4", "%esp"});
            rstack.push(reg);
            temp_offset += 4;
            return;
        }
        if (temp->op == "MINUS_INT"){
            Regs reg = rstack.top();
            rstack.pop();
            code.push_back({MOVL, "movl", std::to_string(temp_offset)+"(%ebp)", get_reg_name(rstack.top())});
            if (temp->left->type.t == PTR_TYPE || temp->left->type.t == ARRAY_TYPE){
                code.push_back({IMULL, "imull", "$"+std::to_string(temp->left->type.element_type->size), get_reg_name(rstack.top())});
            }
            code.push_back({SUBL, "subl", get_reg_name(rstack.top()), get_reg_name(reg)});
            code.push_back({ADDL, "addl", "$4", "%esp"});
            rstack.push(reg);
            temp_offset += 4;
            return;
        }
        if (temp->op == "MULT_INT"){
            code.push_back({IMULL, "imull", std::to_string(temp_offset)+"(%ebp)", get_reg_name(rstack.top())});
            code.push_back({ADDL, "addl", "$4", "%esp"});
            temp_offset += 4;
            return;
        }
        if (temp->op == "DIV_INT"){
            if (rstack.top() != EDX)
                code.push_back({PUSHL, "pushl", "%edx"});
            if (rstack.top() != EAX){
                code.push_back({PUSHL, "pushl", "%eax"});
                code.push_back({MOVL, "movl", get_reg_name(rstack.top()), "%eax"});
            }
            code.push_back({CLTD, "cltd"});
            code.push_back({IDIVL, "idivl", std::to_string(temp_offset)+"(%ebp)"});
            if (rstack.top() != EAX){
                code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                code.push_back({POPL, "popl", "%eax"});
            }
            if (rstack.top() != EDX)
                code.push_back({POPL, "popl", "%edx"});
            code.push_back({ADDL, "addl", "$4", "%esp"});
            temp_offset += 4;
            return;
        }
        // ==
        if (temp->op == "EQ_OP_INT"){
            if (rstack.top() != EAX){
                code.push_back({PUSHL, "pushl", "%eax"});
                code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), std::to_string(temp_offset)+"(%ebp)"});
                code.push_back({SETE, "sete", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                code.push_back({POPL, "popl", "%eax"});
                code.push_back({ADDL, "addl", "$4", "%esp"});
                temp_offset += 4;
                return;
            }
            code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), std::to_string(temp_offset)+"(%ebp)"});
            code.push_back({SETE, "sete", "%al"});
            code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
            code.push_back({ADDL, "addl", "$4", "%esp"});
            temp_offset += 4;
            return;
        }
        // !=
        if (temp->op == "NE_OP_INT"){
            if (rstack.top() != EAX){
                code.push_back({PUSHL, "pushl", "%eax"});
                code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), std::to_string(temp_offset)+"(%ebp)"});
                code.push_back({SETNE, "setne", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                code.push_back({POPL, "popl", "%eax"});
                code.push_back({ADDL, "addl", "$4", "%esp"});
                temp_offset += 4;
                return;
            }
            code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), std::to_string(temp_offset)+"(%ebp)"});
            code.push_back({SETNE, "setne", "%al"});
            code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
            code.push_back({ADDL, "addl", "$4", "%esp"});
            temp_offset += 4;
            return;
        }
        // <
        if (temp->op == "LT_OP_INT"){
            if (rstack.top() != EAX){
                code.push_back({PUSHL, "pushl", "%eax"});
                code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), std::to_string(temp_offset)+"(%ebp)"});
                code.push_back({SETG, "setg", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                code.push_back({POPL, "popl", "%eax"});
                code.push_back({ADDL, "addl", "$4", "%esp"});
                temp_offset += 4;
                return;
            }
            code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), std::to_string(temp_offset)+"(%ebp)"});
            code.push_back({SETG, "setg", "%al"});
            code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
            code.push_back({ADDL, "addl", "$4", "%esp"});
            temp_offset += 4;
            return;
        }
        // >
        if (temp->op == "GT_OP_INT"){
            if (rstack.top() != EAX){
                code.push_back({PUSHL, "pushl", "%eax"});
                code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), std::to_string(temp_offset)+"(%ebp)"});
                code.push_back({SETL, "setl", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                code.push_back({POPL, "popl", "%eax"});
                code.push_back({ADDL, "addl", "$4", "%esp"});
                temp_offset += 4;
                return;
            }
            code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), std::to_string(temp_offset)+"(%ebp)"});
            code.push_back({SETL, "setl", "%al"});
            code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
            code.push_back({ADDL, "addl", "$4", "%esp"});
            temp_offset += 4;
            return;
        }
        // <=
        if (temp->op == "LE_OP_INT"){
            if (rstack.top() != EAX){
                code.push_back({PUSHL, "pushl", "%eax"});
                code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), std::to_string(temp_offset)+"(%ebp)"});
                code.push_back({SETGE, "setge", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                code.push_back({POPL, "popl", "%eax"});
                code.push_back({ADDL, "addl", "$4", "%esp"});
                temp_offset += 4;
                return;
            }
            code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), std::to_string(temp_offset)+"(%ebp)"});
            code.push_back({SETGE, "setge", "%al"});
            code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
            code.push_back({ADDL, "addl", "$4", "%esp"});
            temp_offset += 4;
            return;
        }
        // >=
        if (temp->op == "GE_OP_INT"){
            if (rstack.top() != EAX){
                code.push_back({PUSHL, "pushl", "%eax"});
                code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), std::to_string(temp_offset)+"(%ebp)"});
                code.push_back({SETLE, "setle", "%al"});
                code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
                code.push_back({MOVL, "movl", "%eax", get_reg_name(rstack.top())});
                code.push_back({POPL, "popl", "%eax"});
                code.push_back({ADDL, "addl", "$4", "%esp"});
                temp_offset += 4;
                return;
            }
            code.push_back({CMPL, "cmpl", get_reg_name(rstack.top()), std::to_string(temp_offset)+"(%ebp)"});
            code.push_back({SETLE, "setle", "%al"});
            code.push_back({MOVZBL, "movzbl", "%al", "%eax"});
            code.push_back({ADDL, "addl", "$4", "%esp"});
            temp_offset += 4;
            return;
        }
    } 
}

void CodeGen :: gencode_bool_expr(abstract_astnode* node, std::vector<Instr>& code, SymTab* st){
    typeExp type = node->astnode_type;
    if (type == OP_UNARY_ASTNODE){
        auto temp = (op_unary_astnode*) node;
        // !x
        gencode_expr(temp->expr, code, st, temp->expr->type.t == ARRAY_TYPE);
        // clean up temporaries 
        if (add_offset)
            code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
        temp_offset += add_offset;
        add_offset = 0;

        code.push_back({CMPL, "cmpl", "$0", get_reg_name(rstack.top())});
        auto label1 = get_label();
        code.push_back({JE, "je", label1});
        code.push_back({MOVL, "movl", "$0", get_reg_name(rstack.top())});
        auto label2 = get_label();
        code.push_back({JMP, "jmp", label2});
        code.push_back({STR, label1 + ":"});
        code.push_back({MOVL, "movl", "$1", get_reg_name(rstack.top())});
        code.push_back({STR, label2 + ":"});
        return;
    }
    if (type == OP_BINARY_ASTNODE){
        auto temp = (op_binary_astnode*) node;
        if (temp->right->astnode_type == IDENTIFIER_ASTNODE){
            gencode_expr(temp->left, code, st, temp->left->type.t == ARRAY_TYPE);
            // clean up temporaries 
            if (add_offset)
                code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
            temp_offset += add_offset;
            add_offset = 0;

            if (temp->op == "AND_OP"){
                auto id = ((identifier_astnode*)temp->right)->id;
                int offset = st->entries[id].offset;
                code.push_back({CMPL, "cmpl", "$0", get_reg_name(rstack.top())});
                auto label1 = get_label();
                code.push_back({JE, "je", label1}); // false jump
                // no compares in this case
                if (st->entries[id].t.t != ARRAY_TYPE){
                    code.push_back({CMPL, "cmpl", "$0", std::to_string(offset)+"(%ebp)"});
                    code.push_back({JE, "je", label1}); // false jump
                } 
                code.push_back({MOVL, "movl", "$1", get_reg_name(rstack.top())});
                auto label2 = get_label();
                code.push_back({JMP, "jmp", label2});
                code.push_back({STR, label1 + ":"});
                code.push_back({MOVL, "movl", "$0", get_reg_name(rstack.top())});
                code.push_back({STR, label2 + ":"});
                return;
            }
            if (temp->op == "OR_OP"){
                auto id = ((identifier_astnode*)temp->right)->id;
                int offset = st->entries[id].offset;
                code.push_back({CMPL, "cmpl", "$0", get_reg_name(rstack.top())});
                auto label1 = get_label();
                code.push_back({JNE, "jne", label1}); // true jump
                if (st->entries[id].t.t != ARRAY_TYPE){
                    code.push_back({CMPL, "cmpl", "$0", std::to_string(offset)+"(%ebp)"});
                    code.push_back({JNE, "jne", label1}); // true jump
                } else {
                    code.push_back({JMP, "jmp", label1}); // true jump
                }
                code.push_back({MOVL, "movl", "$0", get_reg_name(rstack.top())});
                auto label2 = get_label();
                code.push_back({JMP, "jmp", label2});
                code.push_back({STR, label1 + ":"});
                code.push_back({MOVL, "movl", "$1", get_reg_name(rstack.top())});
                code.push_back({STR, label2 + ":"});
                return;
            }
        }
        if (temp->right->astnode_type == INTCONST_ASTNODE){
            gencode_expr(temp->left, code, st, temp->left->type.t == ARRAY_TYPE);
            // clean up temporaries 
            if (add_offset)
                code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
            temp_offset += add_offset;
            add_offset = 0;

            std::string val = std::to_string(((intconst_astnode*)temp->right)->val);
            if (temp->op == "AND_OP"){
                code.push_back({CMPL, "cmpl", "$0", get_reg_name(rstack.top())});
                auto label1 = get_label();
                code.push_back({JE, "je", label1}); 
                if (val == "0"){
                    code.push_back({JMP, "jmp", label1});
                }
                code.push_back({MOVL, "movl", "$1", get_reg_name(rstack.top())});
                auto label2 = get_label();
                code.push_back({JMP, "jmp", label2});
                code.push_back({STR, label1 + ":"});
                code.push_back({MOVL, "movl", "$0", get_reg_name(rstack.top())});
                code.push_back({STR, label2 + ":"});
                return;
            }
            if (temp->op == "OR_OP"){
                code.push_back({CMPL, "cmpl", "$0", get_reg_name(rstack.top())});
                auto label1 = get_label();
                code.push_back({JNE, "jne", label1});
                if (val != "0"){
                    code.push_back({JMP, "jmp", label1});
                }
                code.push_back({MOVL, "movl", "$0", get_reg_name(rstack.top())});
                auto label2 = get_label();
                code.push_back({JMP, "jmp", label2});
                code.push_back({STR, label1 + ":"});
                code.push_back({MOVL, "movl", "$1", get_reg_name(rstack.top())});
                code.push_back({STR, label2 + ":"});
                return;
            }
        }
        if (temp->right->label < (int)rstack.size()){
            gencode_expr(temp->left, code, st, temp->left->type.t == ARRAY_TYPE);
            // clean up temporaries 
            if (add_offset)
                code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
            temp_offset += add_offset;
            add_offset = 0;

            Regs reg = rstack.top();
            rstack.pop();
            gencode_expr(temp->right, code, st, temp->right->type.t == ARRAY_TYPE);
            // clean up temporaries 
            if (add_offset)
                code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
            temp_offset += add_offset;
            add_offset = 0;

            if (temp->op == "AND_OP"){
                code.push_back({CMPL, "cmpl", "$0", get_reg_name(reg)});
                auto label1 = get_label();
                code.push_back({JE, "je", label1}); // false jump
                code.push_back({CMPL, "cmpl", "$0", get_reg_name(rstack.top())});
                code.push_back({JE, "je", label1}); // false jump
                code.push_back({MOVL, "movl", "$1", get_reg_name(reg)});
                auto label2 = get_label();
                code.push_back({JMP, "jmp", label2});
                code.push_back({STR, label1 + ":"});
                code.push_back({MOVL, "movl", "$0", get_reg_name(reg)});
                code.push_back({STR, label2 + ":"});
                rstack.push(reg);
                return;
            }
            if (temp->op == "OR_OP"){
                code.push_back({CMPL, "cmpl", "$0", get_reg_name(reg)});
                auto label1 = get_label();
                code.push_back({JNE, "jne", label1}); // true jump
                code.push_back({CMPL, "cmpl", "$0", get_reg_name(rstack.top())});
                code.push_back({JNE, "jne", label1}); // true jump
                code.push_back({MOVL, "movl", "$0", get_reg_name(reg)});
                auto label2 = get_label();
                code.push_back({JMP, "jmp", label2});
                code.push_back({STR, label1 + ":"});
                code.push_back({MOVL, "movl", "$1", get_reg_name(reg)});
                code.push_back({STR, label2 + ":"});
                rstack.push(reg);
                return;
            }
        }
        if (temp->left->label < (int)rstack.size()){
            swap(rstack);
            gencode_expr(temp->right, code, st, temp->right->type.t == ARRAY_TYPE);
            // clean up temporaries 
            if (add_offset)
                code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
            temp_offset += add_offset;
            add_offset = 0;

            Regs reg = rstack.top();
            rstack.pop();
            gencode_expr(temp->left, code, st, temp->left->type.t == ARRAY_TYPE);
            // clean up temporaries 
            if (add_offset)
                code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
            temp_offset += add_offset;
            add_offset = 0;

            if (temp->op == "AND_OP"){
                code.push_back({CMPL, "cmpl", "$0", get_reg_name(rstack.top())});
                auto label1 = get_label();
                code.push_back({JE, "je", label1}); // false jump
                code.push_back({CMPL, "cmpl", "$0", get_reg_name(reg)});
                code.push_back({JE, "je", label1}); // false jump
                code.push_back({MOVL, "movl", "$1", get_reg_name(rstack.top())});
                auto label2 = get_label();
                code.push_back({JMP, "jmp", label2});
                code.push_back({STR, label1 + ":"});
                code.push_back({MOVL, "movl", "$0", get_reg_name(rstack.top())});
                code.push_back({STR, label2 + ":"});
                rstack.push(reg);
                swap(rstack);
                return;
            }
            if (temp->op == "OR_OP"){
                code.push_back({CMPL, "cmpl", "$0", get_reg_name(rstack.top())});
                auto label1 = get_label();
                code.push_back({JNE, "jne", label1}); // true jump
                code.push_back({CMPL, "cmpl", "$0", get_reg_name(reg)});
                code.push_back({JNE, "jne", label1}); // true jump
                code.push_back({MOVL, "movl", "$0", get_reg_name(rstack.top())});
                auto label2 = get_label();
                code.push_back({JMP, "jmp", label2});
                code.push_back({STR, label1 + ":"});
                code.push_back({MOVL, "movl", "$1", get_reg_name(rstack.top())});
                code.push_back({STR, label2 + ":"});
                rstack.push(reg);
                swap(rstack);
                return;
            }
        }
        gencode_expr(temp->right, code, st, temp->right->type.t == ARRAY_TYPE);
        // clean up temporaries 
        if (add_offset)
            code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
        temp_offset += add_offset;
        add_offset = 0;

        temp_offset -= 4;
        code.push_back({SUBL, "subl", "$4", "%esp"});
        code.push_back({MOVL, "movl", get_reg_name(rstack.top()), std::to_string(temp_offset)+"(%ebp)"});
        gencode_expr(temp->left, code, st, temp->left->type.t == ARRAY_TYPE);
        // clean up temporaries 
        if (add_offset)
            code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
        temp_offset += add_offset;
        add_offset = 0;

        if (temp->op == "AND_OP"){
            code.push_back({CMPL, "cmpl", "$0", get_reg_name(rstack.top())});
            auto label1 = get_label();
            code.push_back({JE, "je", label1}); // false jump
            code.push_back({CMPL, "cmpl", "$0", std::to_string(temp_offset)+"(%ebp)"});
            code.push_back({JE, "je", label1}); // false jump
            code.push_back({MOVL, "movl", "$1", get_reg_name(rstack.top())});
            auto label2 = get_label();
            code.push_back({JMP, "jmp", label2});
            code.push_back({STR, label1 + ":"});
            code.push_back({MOVL, "movl", "$0", get_reg_name(rstack.top())});
            code.push_back({STR, label2 + ":"});
            code.push_back({ADDL, "addl", "$4", "%esp"});
            temp_offset += 4;
            return;
        }
        if (temp->op == "OR_OP"){
            code.push_back({CMPL, "cmpl", "$0", get_reg_name(rstack.top())});
            auto label1 = get_label();
            code.push_back({JNE, "jne", label1}); // true jump
            code.push_back({CMPL, "cmpl", "$0", std::to_string(temp_offset)+"(%ebp)"});
            code.push_back({JNE, "jne", label1}); // true jump
            code.push_back({MOVL, "movl", "$0", get_reg_name(rstack.top())});
            auto label2 = get_label();
            code.push_back({JMP, "jmp", label2});
            code.push_back({STR, label1 + ":"});
            code.push_back({MOVL, "movl", "$1", get_reg_name(rstack.top())});
            code.push_back({STR, label2 + ":"});
            code.push_back({ADDL, "addl", "$4", "%esp"});
            temp_offset += 4;
            return;
        }
    }
}

void CodeGen :: gencode_assign(exp_astnode* left, exp_astnode* right, std::vector<Instr>& code, SymTab* st){
    
    if (right->label < (int)rstack.size()){
        // std::cout << right->label << "\n";
        // std::cout << "assign right\n";
        gencode_expr(left, code, st, true);
        // std::cout << get_code_from_instr(code.back()) << "\n";
        Regs reg = rstack.top();
        rstack.pop();
        // std::cout <<
        // std::cout << "ASSIGN_RIGHT\n";
        if (left->type.t == STRUCT_TYPE){
            gencode_expr(right, code, st, true);
            int sz = left->type.size;
            for (int i=0;i<sz;i+=4){
                temp_offset -= 4;
                code.push_back({PUSHL, "pushl", get_reg_name(rstack.top())});
                code.push_back({MOVL, "movl", (i == 0 ? "" : std::to_string(i))+"("+get_reg_name(rstack.top())+")", get_reg_name(rstack.top())});
                code.push_back({MOVL, "movl", get_reg_name(rstack.top()), (i == 0 ? "" : std::to_string(i))+"("+get_reg_name(reg)+")"});
                code.push_back({POPL, "popl", get_reg_name(rstack.top())});
                temp_offset += 4;
            }
            // if (right->astnode_type == FUNCALL_ASTNODE){
            //     temp_offset += add_offset;
            //     int n = regs_to_pop.size();
            //     code.push_back({ADDL, "addl", "$"+std::to_string(add_offset+4*n), "%esp"});
            //     temp_offset += 4*n;
            //     regs_to_pop.clear();
            //     add_offset = 0;
            // }
            rstack.push(reg);
            return;
        }
        // std::cout << "rstack.size() " << rstack.size() << "\n";
        gencode_expr(right, code, st);
        code.push_back({MOVL, "movl", get_reg_name(rstack.top()), "("+get_reg_name(reg)+")"});
        rstack.push(reg);
        return;
    }
    if (left->label < (int)rstack.size()){
        // std::cout << "assign left\n";
        swap(rstack);
        gencode_expr(right, code, st, left->type.t == STRUCT_TYPE);
        Regs reg = rstack.top();
        rstack.pop();
        gencode_expr(left, code, st, true);
        if (left->type.t == STRUCT_TYPE){
            int sz = left->type.size;
            for (int i=0;i<sz;i+=4){
                temp_offset -= 4;
                code.push_back({PUSHL, "pushl", get_reg_name(reg)});
                code.push_back({MOVL, "movl", (i == 0 ? "" : std::to_string(i))+"("+get_reg_name(reg)+")", get_reg_name(reg)});
                code.push_back({MOVL, "movl", get_reg_name(reg), (i == 0 ? "" : std::to_string(i))+"("+get_reg_name(rstack.top())+")"});
                code.push_back({POPL, "popl", get_reg_name(reg)});
                temp_offset += 4;
            }
            // if (right->astnode_type == FUNCALL_ASTNODE){
            //     int n = regs_to_pop.size();
            //     temp_offset += add_offset;
            //     code.push_back({ADDL, "addl", "$"+std::to_string(add_offset+4*n), "%esp"});
            //     temp_offset += 4*n;
            //     regs_to_pop.clear();
            //     add_offset = 0;
            // }
            rstack.push(reg);
            swap(rstack);
            return;
        }
        code.push_back({MOVL, "movl", get_reg_name(reg), "("+get_reg_name(rstack.top())+")"});
        rstack.push(reg);
        swap(rstack);
        return;
    }
    // std::cout << "assign last\n";
    gencode_expr(right, code, st, left->type.t == STRUCT_TYPE);
    temp_offset -= 4;
    code.push_back({SUBL, "subl", "$4", "%esp"});
    code.push_back({MOVL, "movl", get_reg_name(rstack.top()), std::to_string(temp_offset)+"(%ebp)"});
    gencode_expr(left, code, st, true);
    if (left->type.t == STRUCT_TYPE){
        Regs reg = rstack.top();
        rstack.pop();
        int sz = left->type.size;
        for (int i=0;i<sz;i+=4){
            code.push_back({MOVL, "movl", std::to_string(temp_offset)+"(%ebp)", get_reg_name(rstack.top())});
            code.push_back({MOVL, "movl", (i==0 ? "" : std::to_string(i))+"("+get_reg_name(rstack.top())+")", get_reg_name(rstack.top())});
            code.push_back({MOVL, "movl", get_reg_name(rstack.top()), (i==0 ? "" : std::to_string(i))+"("+get_reg_name(reg)+")"});
        }
        // if (right->astnode_type == FUNCALL_ASTNODE){
        //     int n = regs_to_pop.size();
        //     temp_offset += add_offset;
        //     code.push_back({ADDL, "addl", "$"+std::to_string(add_offset+4*n), "%esp"});
        //     temp_offset += 4*n;
        //     regs_to_pop.clear();
        //     add_offset = 0;
        // }
        code.push_back({ADDL, "addl", "$4", "%esp"});
        temp_offset += 4;
        rstack.push(reg);
        return;
    }
    Regs reg = rstack.top();
    rstack.pop();
    code.push_back({MOVL, "movl", std::to_string(temp_offset)+"(%ebp)", get_reg_name(rstack.top())});
    code.push_back({MOVL, "movl", get_reg_name(rstack.top()), "("+get_reg_name(reg)+")"});
    code.push_back({ADDL, "addl", "$4", "%esp"});
    rstack.push(reg);
    temp_offset += 4;
    return;
}

void CodeGen :: gencode_printf(proccall_astnode* node, std::vector<Instr>& code, SymTab* st){
    auto format_str = ((stringconst_astnode*)(node->args[0]))->val;
    if (!format_strings.count(format_str))
        format_strings[format_str] = ".STR"+std::to_string(format_strings.size());
    int cnt = 1;
    for (int i=(int)node->args.size()-1;i>=1;i--){
        gencode_expr(node->args[i], code, st);
        // free evaluated temporary
        if (add_offset)
            code.push_back({ADDL, "addl", "$"+std::to_string(add_offset), "%esp"});
        temp_offset += add_offset;
        add_offset = 0;
        code.push_back({PUSHL, "pushl", get_reg_name(rstack.top())});
        temp_offset -= 4;
        cnt++;
    }
    cnt *= 4;
    temp_offset -= 4;
    code.push_back({PUSHL, "pushl", "$"+format_strings[format_str]});
    code.push_back({CALL, "call", "printf"});
    code.push_back({ADDL, "addl", "$"+std::to_string(cnt), "%esp"});
    temp_offset += cnt;
    
}

const std::string& CodeGen :: get_reg_name(Regs reg){
    return reg_names[reg];
}

void CodeGen :: swap(std::stack<Regs>& rstack){
    auto tmp1 = rstack.top();
    rstack.pop();
    auto tmp2 = rstack.top();
    rstack.pop();
    rstack.push(tmp1);
    rstack.push(tmp2);
}