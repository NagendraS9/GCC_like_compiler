#ifndef _CODEGEN_H_
#define _CODEGEN_H_

#include <vector>
#include <string>
#include <map>
#include <stack>

#include "ast.hh"
#include "symtab.hh"

enum InstrType{PUSHL, POPL, CALL, MOVL, LEAL, CLTD, NEGL,
               LEAVE, RET, ADDL, SUBL, IMULL, IDIVL, CMPL,
               SETE, SETNE, SETGE, SETLE, SETG, SETL,
               JE, JGE, JMP, JNE, JLE, JG, JL,
               MOVZBL, STR};
enum Regs{EAX, EBX, ECX, EDX, ESI, EDI};

struct Instr{
    InstrType type;
    std::string instr;
    std::string op1;
    std::string op2;
};

class CodeGen{
    public:
        void attribution(abstract_astnode* node);
        void gencode(abstract_astnode* node, std::vector<Instr>& code, SymTab* st);
        void gencode_expr(abstract_astnode* node, std::vector<Instr>& code, SymTab* st, bool addr = false);
        void gencode_bool_expr(abstract_astnode* node, std::vector<Instr>& code, SymTab* st);
        void gencode_assign(exp_astnode* left, exp_astnode* right, std::vector<Instr>& code, SymTab* st);
        void gencode_printf(proccall_astnode* node, std::vector<Instr>& code, SymTab* st);
        
        void set_temp_offset(int offset){ temp_offset = offset; }
        void set_gst(SymTab* gst){ this->gst = gst; }
        const std::string& get_reg_name(Regs reg); 
        void swap(std::stack<Regs>& rstack);
        
        void fill_stack();
        std::string get_label(){ return ".L"+std::to_string(label++);};
        std::string get_format_strings() const;
        std::string get_code_from_instr(const Instr& instr) const;
    private:
        SymTab* gst;
        std::vector<Regs> regs_to_pop;
        int add_offset = 0;
        std::map<std::string, std::string> format_strings;
        std::stack<Regs> rstack;
        const std::vector<std::string> reg_names {"%eax", "%ebx", "%ecx", "%edx", "%esi", "%edi"};
        int temp_offset = 0;
        int label = 0;
};

#endif