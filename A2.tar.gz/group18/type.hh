#ifndef _TYPE_H_
#define _TYPE_H_

#include <string>
#include <memory>
#include <iostream>

enum type{VOID_TYPE, INT_TYPE, FLOAT_TYPE
        , STRING_CONST, PTR_TYPE, STRUCT_TYPE
        , ARRAY_TYPE};

struct datatype{
    public:
        type t;
        std::string decl_type_name;
        std::string inferred_type_name;
        int size;
        int n;
        datatype* element_type;
};

datatype createtype(type t);                            // basic types
datatype createtype(type t, const datatype& e_type);    // pointer types
datatype createtype(const std::string& struct_type, int size);  // struct type
datatype createtype(int n, const datatype& e_type);             // array type
bool compare_types_funcall(const datatype& t1, const datatype& t2);
bool compare_types_minus(const datatype& left, const datatype& right);
bool compare_types_plus(const datatype& left, const datatype& right);
bool compare_types_relational(const datatype& left, const datatype& right, bool isZero_left, bool isZero_right);
bool compare_types_equality(const datatype& left, const datatype& right, bool isZero_left, bool isZero_right);
bool compare_types_assign(const datatype& left, const datatype& right);

#endif