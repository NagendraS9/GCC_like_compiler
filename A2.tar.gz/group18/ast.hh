#ifndef _AST_H_
#define _AST_H_

#include <vector>
#include <string>

enum typeExp{EMPTY_ASTNODE, SEQ_ASTNODE, ASSIGNS_ASTNODE
           , RETURN_ASTNODE, IF_ASTNODE, WHILE_ASTNODE
           , FOR_ASTNODE, PROCCALL_ASTNODE, IDENTIFIER_ASTNODE
           , ARRAYREF_ASTNODE, MEMBER_ASTNODE, ARROW_ASTNODE
           , OP_BINARY_ASTNODE, OP_UNARY_ASTNODE, ASSIGNE_ASTNODE
           , FUNCALL_ASTNODE, INTCONST_ASTNODE, FLOATCONST_ASTNODE
           , STRINGCONST_ASTNODE};

class abstract_astnode{
    public:
        typeExp astnode_type;

        virtual void print() = 0;
};

class statement_astnode : public abstract_astnode{

};

class exp_astnode : public abstract_astnode{

};

class ref_astnode : public exp_astnode{

};

class identifier_astnode;

class empty_astnode : public statement_astnode{
    public:

        empty_astnode(){
            astnode_type = EMPTY_ASTNODE;
        }
        virtual void print() override;;
};

class seq_astnode : public statement_astnode{
    public:
        std::vector<statement_astnode*> children;

        seq_astnode(){
            astnode_type = SEQ_ASTNODE;
        }
        seq_astnode(const std::vector<statement_astnode*>& children) : children(children){
            astnode_type = SEQ_ASTNODE;
        }
        virtual void print() override;
};

class assignS_astnode : public statement_astnode{
    public:
        exp_astnode* left;
        exp_astnode* right;

        assignS_astnode(){
            astnode_type = ASSIGNS_ASTNODE;
        }
        assignS_astnode(exp_astnode* left, exp_astnode* right)
            : left(left), right(right)
        {
            astnode_type = ASSIGNS_ASTNODE;
        }
        virtual void print() override;
};

class return_astnode : public statement_astnode{
    public:
        exp_astnode* child;

        return_astnode(){
            astnode_type = RETURN_ASTNODE;
        }
        return_astnode(exp_astnode* child) : child(child){
            astnode_type = RETURN_ASTNODE;
        }
        virtual void print() override;
};

class proccall_astnode : public statement_astnode{
    public:
        identifier_astnode* fname;
        std::vector<exp_astnode*> args;

        proccall_astnode(){
            astnode_type = PROCCALL_ASTNODE;
        }
        proccall_astnode(identifier_astnode* fname, const std::vector<exp_astnode*>& args)
            : fname(fname), args(args)
        {
            astnode_type = PROCCALL_ASTNODE;    
        }
        virtual void print() override;
};

class if_astnode : public statement_astnode{
    public:
        exp_astnode* cond;
        statement_astnode* true_stmt;
        statement_astnode* false_stmt;

        if_astnode(){
            astnode_type = IF_ASTNODE;
        }
        if_astnode(exp_astnode* cond, statement_astnode* true_stmt, statement_astnode* false_stmt)
            : cond(cond), true_stmt(true_stmt), false_stmt(false_stmt)
        {
            astnode_type = IF_ASTNODE;
        }
        virtual void print() override;
};

class while_astnode : public statement_astnode{
    public:
        exp_astnode* cond;
        statement_astnode* stmt;

        while_astnode(){
            astnode_type = WHILE_ASTNODE;
        }
        while_astnode(exp_astnode* cond, statement_astnode* stmt)
            : cond(cond), stmt(stmt)
        {
            astnode_type = WHILE_ASTNODE;
        }
        virtual void print() override;
};

class for_astnode : public statement_astnode{   
    public:
        exp_astnode* init;
        exp_astnode* guard;
        exp_astnode* step;
        statement_astnode* stmt;

        for_astnode(){
            astnode_type = FOR_ASTNODE;
        }
        for_astnode(exp_astnode* init, exp_astnode* guard, exp_astnode* step, statement_astnode* stmt)
            : init(init), guard(guard), step(step), stmt(stmt)
        {
            astnode_type = FOR_ASTNODE;
        }
        virtual void print() override;
};

class op_binary_astnode : public exp_astnode{
    public:
        std::string op;
        exp_astnode* left;
        exp_astnode* right;

        op_binary_astnode(){
            astnode_type = OP_BINARY_ASTNODE;
        }
        op_binary_astnode(const std::string& op, exp_astnode* left, exp_astnode* right)
            : op(op), left(left), right(right)
        {
            astnode_type = OP_BINARY_ASTNODE;
        }
        virtual void print() override;
};

class op_unary_astnode : public exp_astnode{
    public:
        std::string op;
        exp_astnode* expr;

        op_unary_astnode(){
            astnode_type = OP_UNARY_ASTNODE;
        }
        op_unary_astnode(const std::string& op, exp_astnode* expr)
            : op(op), expr(expr)
        {
            astnode_type = OP_UNARY_ASTNODE;
        }
        virtual void print() override;
};

class assignE_astnode : public exp_astnode{
    public:
        exp_astnode* left;
        exp_astnode* right;

        assignE_astnode(){
            astnode_type = ASSIGNE_ASTNODE;
        }
        assignE_astnode(exp_astnode* left, exp_astnode* right)
            : left(left), right(right)
        {
            astnode_type = ASSIGNE_ASTNODE;
        }
        virtual void print() override;
};

class funcall_astnode : public exp_astnode{
    public:
        identifier_astnode* fname;
        std::vector<exp_astnode*> args;

        funcall_astnode(){
            astnode_type = FUNCALL_ASTNODE;
        }
        funcall_astnode(identifier_astnode* fname, const std::vector<exp_astnode*>& args)
            : fname(fname), args(args)
        {
            astnode_type = FUNCALL_ASTNODE;
        }
        virtual void print() override;
};

class floatconst_astnode : public exp_astnode{
    public:
        float val;

        floatconst_astnode(){
            astnode_type = FLOATCONST_ASTNODE;
        }
        floatconst_astnode(float val) : val(val){
            astnode_type = FLOATCONST_ASTNODE;
        }
        virtual void print() override;
};

class intconst_astnode : public exp_astnode{
    public:
        int val;

        intconst_astnode(){
            astnode_type = INTCONST_ASTNODE;
        }
        intconst_astnode(int val) : val(val){
            astnode_type = INTCONST_ASTNODE;
        }
        virtual void print() override;
};

class stringconst_astnode : public exp_astnode{
    public:
        std::string val;

        stringconst_astnode(){
            astnode_type = STRINGCONST_ASTNODE;
        }
        stringconst_astnode(const std::string& val) : val(val){
            astnode_type = STRINGCONST_ASTNODE;
        }
        virtual void print() override;
};

class identifier_astnode : public ref_astnode{
    public:
        std::string id;

        identifier_astnode(){
            astnode_type = IDENTIFIER_ASTNODE;
        }
        identifier_astnode(const std::string& id) : id(id){
            astnode_type = IDENTIFIER_ASTNODE;
        }
        virtual void print() override;
};

class member_astnode : public ref_astnode{
    public:
        exp_astnode* expr;
        identifier_astnode* identifier;

        member_astnode(){
            astnode_type = MEMBER_ASTNODE;
        }
        member_astnode(exp_astnode* expr, identifier_astnode* identifier)
            : expr(expr), identifier(identifier)
        {
            astnode_type = MEMBER_ASTNODE;
        }
        virtual void print() override;
};

class arrow_astnode : public ref_astnode{
    public:
        exp_astnode* expr;
        identifier_astnode* identifier;

        arrow_astnode(){
            astnode_type = ARROW_ASTNODE;
        }
        arrow_astnode(exp_astnode* expr, identifier_astnode* identifier)
            : expr(expr), identifier(identifier)
        {
            astnode_type = ARROW_ASTNODE;
        }
        virtual void print() override;
};

class arrayref_astnode : public ref_astnode{
    public:
        exp_astnode* array;
        exp_astnode* idx;

        arrayref_astnode(){
            astnode_type = ARRAYREF_ASTNODE;
        }
        arrayref_astnode(exp_astnode* array, exp_astnode* idx)
            : array(array), idx(idx)
        {
            astnode_type = ARRAYREF_ASTNODE;
        }
        virtual void print() override;
};

#endif