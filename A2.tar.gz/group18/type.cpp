#include "type.hh"
#include <iostream>

#define PTR_SIZE 4

datatype createtype(type t){ //basic types
    datatype dtype;
    dtype.t = t;
    dtype.size = 4;
    if(t == VOID_TYPE){
        dtype.decl_type_name = dtype.inferred_type_name = "void";
    } else if(t == INT_TYPE){
        dtype.decl_type_name = dtype.inferred_type_name = "int";
    } else if(t == FLOAT_TYPE){
        dtype.decl_type_name = dtype.inferred_type_name = "float";
    } else if(t == STRING_CONST){
        dtype.decl_type_name = dtype.inferred_type_name = "stringconst";
    } else{
        std::cerr << "Invalid type : Expected types are VOID_TYPE, INT_TYPE, FLOAT_TYPE\n";
        exit(1);
    }
    return dtype;
}

datatype createtype(type t, const datatype& e_type){ // pointer type
    datatype dtype;
    dtype.t = t;
    if(t == PTR_TYPE){
        if (e_type.t == ARRAY_TYPE){        // pointer to an array
            dtype.decl_type_name = "";
            const datatype* temp = &e_type;
            while (temp->t == ARRAY_TYPE){
                dtype.decl_type_name += "["+std::to_string(temp->n)+"]";
                temp = temp->element_type;
            }
            dtype.decl_type_name = temp->decl_type_name + "(*)" + dtype.decl_type_name;
            dtype.inferred_type_name = dtype.decl_type_name;
            dtype.size = PTR_SIZE;
            dtype.element_type = new datatype(e_type);
        } else if (e_type.t == PTR_TYPE && e_type.element_type->t == ARRAY_TYPE){   // pointer to a pointer to an array
            dtype.decl_type_name = "";
            const datatype* temp = e_type.element_type;
            while (temp->t == ARRAY_TYPE){
                dtype.decl_type_name += "["+std::to_string(temp->n)+"]";
                temp = temp->element_type;
            }
            dtype.decl_type_name = temp->decl_type_name + "(**)" + dtype.decl_type_name;
            dtype.inferred_type_name = dtype.decl_type_name;
            dtype.size = PTR_SIZE;
            dtype.element_type = new datatype(e_type);
        } else {    // regular pointer
            dtype.decl_type_name = dtype.inferred_type_name = e_type.decl_type_name + "*";
            dtype.size = PTR_SIZE;
            dtype.element_type = new datatype(e_type);
        }
    } else{
        std::cerr << "Invalid type : Expected types are PTR_TYPE\n";
        exit(1);
    }
    return dtype;
}

datatype createtype(const std::string& struct_name, int size){ // struct types
    datatype dtype;
    dtype.t = STRUCT_TYPE;
    dtype.decl_type_name = "struct " + struct_name;
    dtype.inferred_type_name = dtype.decl_type_name;
    dtype.size = size;

    return dtype;
}

datatype createtype(int n, const datatype& e_type){ // array types
    datatype dtype;
    dtype.t = ARRAY_TYPE;
    dtype.decl_type_name = "[" + std::to_string(n) + "]";
    dtype.inferred_type_name = (e_type.t != ARRAY_TYPE ? "*" : "(*)");

    auto temp = e_type.element_type;
    if(e_type.t != ARRAY_TYPE){
        dtype.decl_type_name = e_type.decl_type_name + dtype.decl_type_name;
        dtype.inferred_type_name = e_type.decl_type_name + dtype.inferred_type_name;
    } else{
        dtype.decl_type_name += "[" + std::to_string(e_type.n) + "]";
        dtype.inferred_type_name += "[" + std::to_string(e_type.n) + "]";

        while(temp->t == ARRAY_TYPE){
            dtype.decl_type_name += "[" + std::to_string(temp->n) + "]";
            dtype.inferred_type_name += "[" + std::to_string(temp->n) + "]";
            temp = temp->element_type;
        }
        dtype.decl_type_name = temp->decl_type_name + dtype.decl_type_name;
        dtype.inferred_type_name = temp->decl_type_name + dtype.inferred_type_name;
    }
    dtype.n = n;
    dtype.size = n*e_type.size;
    dtype.element_type = new datatype(e_type); 

    return dtype;
}

// t1 is declared arg type and t2 is passed arg  type
bool compare_types_funcall(const datatype& t1, const datatype& t2){
    /*
        float and int compatible
        can pass void* to any ptr or array type
        can pass 1D array to ptr and vice versa
        interpret arrays as (*)element_type
        otherwise match decl_type_name
    */
    if((t1.t == FLOAT_TYPE || t1.t == INT_TYPE) && (t2.t == FLOAT_TYPE || t2.t == INT_TYPE))
        return true;
    
    if (t1.decl_type_name == "void*" && (t2.t == PTR_TYPE || t2.t == ARRAY_TYPE))
        return true;

    if((t1.t == PTR_TYPE || t1.t == ARRAY_TYPE) && t2.decl_type_name == "void*")
        return true;
    if((t1.t == PTR_TYPE || t1.t == ARRAY_TYPE) && (t2.t == PTR_TYPE || t2.t == ARRAY_TYPE)){
        return t1.element_type->decl_type_name == t2.element_type->decl_type_name;
    }
    if(t1.t == STRUCT_TYPE)
        return t1.decl_type_name == t2.decl_type_name;

    return false;
}

bool compare_types_minus(const datatype& left, const datatype& right){
    /*
        int and float compatible
        ptr - ptr
            cannot subtract void* types beside themselves
            can subtract 1D arrays and ptrs if their element types are same
            for nD arrays element types should match
            can subtract matching ptr types
            for refs take them as arrayss with extra dimension
            just match element_types

        ptr-int
            valid for any ptr/array/ref
        
        int-ptr not allowed
    */
    if((left.t == INT_TYPE || left.t == FLOAT_TYPE) && (right.t == INT_TYPE || right.t == FLOAT_TYPE))
        return true;
    
    //ptr - ptr
    if((left.t == PTR_TYPE || left.t == ARRAY_TYPE) && (right.t == PTR_TYPE || right.t == ARRAY_TYPE)){
        return left.element_type->decl_type_name == right.element_type->decl_type_name;
    }

    if((left.t == PTR_TYPE || left.t == ARRAY_TYPE) && right.t == INT_TYPE)
        return true;
    
    return false;
}

bool compare_types_plus(const datatype& left, const datatype& right){
    /*
        same as minus except ptr + ptr allowed and int + ptr allowed
    */
    if((left.t == INT_TYPE || left.t == FLOAT_TYPE) && (right.t == INT_TYPE || right.t == FLOAT_TYPE))
        return true;

    if((left.t == PTR_TYPE || left.t == ARRAY_TYPE) && right.t == INT_TYPE)
        return true;
    
    if(left.t == INT_TYPE && (right.t == PTR_TYPE || right.t == ARRAY_TYPE))
        return true;
    
    return false;
}

bool compare_types_relational(const datatype& left, const datatype& right, bool isZero_left, bool isZero_right){
    /*
        float and int  compatible
        otherwise match element_types
    */
    if((left.t == INT_TYPE || left.t == FLOAT_TYPE) && (right.t == INT_TYPE || right.t == FLOAT_TYPE))
        return true;

    if (((left.t == PTR_TYPE || left.t == ARRAY_TYPE) && isZero_right) || ((right.t == PTR_TYPE || right.t == ARRAY_TYPE) && isZero_left))
        return true;

    if((left.t == PTR_TYPE || left.t == ARRAY_TYPE) && (right.t == PTR_TYPE || right.t == ARRAY_TYPE))
        return left.element_type->decl_type_name == right.element_type->decl_type_name;
    
    return false;
}

bool compare_types_equality(const datatype& left, const datatype& right, bool isZero_left, bool isZero_right){
    /*
        same as relational but void* is comparable to any pointer
    */
    if((left.t == INT_TYPE || left.t == FLOAT_TYPE) && (right.t == INT_TYPE || right.t == FLOAT_TYPE))
        return true;
    
    if (left.decl_type_name == "void*" && (right.t == PTR_TYPE || right.t == ARRAY_TYPE))
        return true;
    
    if ((left.t == PTR_TYPE || left.t == ARRAY_TYPE) && right.decl_type_name == "void*")
        return true;

    if (((left.t == PTR_TYPE || left.t == ARRAY_TYPE) && isZero_right) || ((right.t == PTR_TYPE || right.t == ARRAY_TYPE) && isZero_left))
        return true;
        
    if((left.t == PTR_TYPE || left.t == ARRAY_TYPE) && (right.t == PTR_TYPE || right.t == ARRAY_TYPE))
        return left.element_type->decl_type_name == right.element_type->decl_type_name;

    return false;
}

bool compare_types_assign(const datatype& left, const datatype& right){
    /*
        float and int  compatible
        cannot assign to array types
        void* compatible to all except int and float
        otherwise match element_types
    */
    if((left.t == INT_TYPE || left.t == FLOAT_TYPE) && (right.t == INT_TYPE || right.t == FLOAT_TYPE))
        return true;
    
    if (left.decl_type_name == "void*" && (right.t == PTR_TYPE || right.t == ARRAY_TYPE))
        return true;
    
    if (left.t == PTR_TYPE && right.decl_type_name == "void*")
        return true;
    
    if(left.t == PTR_TYPE && (right.t == PTR_TYPE || right.t == ARRAY_TYPE)){
        return left.element_type->decl_type_name == right.element_type->decl_type_name;
    }
    if(left.t == STRUCT_TYPE)
        return left.decl_type_name == right.decl_type_name;

    return false;
}

