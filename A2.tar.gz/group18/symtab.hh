#ifndef _SYMTAB_H_
#define _SYMTAB_H_

#include <string>
#include <map>
#include <iostream>

#include "type.hh"

class SymTab;

struct Entry{
    std::string varfun;
    std::string scope;
    int size;
    int offset;
    datatype t;
    SymTab* symtab;
    int idx;    // for func params
    std::string type_name;
};

class SymTab{
    public:
        std::map<std::string, Entry> entries;

        void print(bool gst) const {
            int len = entries.size();
            for (const auto& entry : entries){
                std::cout << "[\n";
                std::cout << "\"" << entry.first << "\",\n"
                          << "\"" << entry.second.varfun << "\",\n"
                          << "\"" << entry.second.scope << "\",\n"
                          << entry.second.size << ",\n"
                          << (gst && entry.second.varfun == "struct" ? "\"-\"" : std::to_string(entry.second.offset)) << ",\n"
                          << "\"" << (gst && entry.second.varfun == "struct" ? "-" : entry.second.type_name) << "\"\n";
                std::cout << "]";
                std::cout << (len == 1 ? "\n" : ",");
                --len;
            }
        }
};

#endif