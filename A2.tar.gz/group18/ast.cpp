#include "ast.hh"

#include <iostream>

void empty_astnode :: print(){
    std::cout << "\"empty\"";
}

void seq_astnode :: print(){
    std::cout << "{\n\"seq\": [\n";
    int n = children.size();
    for (int i=0;i<n;i++){
        children[i]->print();
        if (i != n-1) std::cout << ",\n";
    }
    std::cout << "\n]\n}";
}

void assignS_astnode :: print(){
    std::cout << "{\n\"assignS\": {\n";
    std::cout << "\"left\": ";
    left->print();
    std::cout << ",\n";
    std::cout << "\"right\": ";
    right->print();
    std::cout << "\n}\n}";
}

void return_astnode :: print(){
    std::cout << "{\n\"return\": ";
    child->print();
    std::cout << "\n}";
}

void proccall_astnode :: print(){
    std::cout << "{\n\"proccall\": {\n";
    std::cout << "\"fname\": \n";
    fname->print();
    std::cout << ",\n";
    std::cout << "\"params\": [\n";
    int n = args.size();
    for (int i=0;i<n;i++){
        args[i]->print();
        if (i != n-1) std::cout << ",\n";
    }
    std::cout << "\n]\n}\n}";
}

void if_astnode :: print(){
    std::cout << "{\n\"if\": {\n";
    std::cout << "\"cond\": \n";
    cond->print();
    std::cout << ",\n";
    std::cout << "\"then\": ";
    true_stmt->print();
    std::cout << ",\n";
    std::cout << "\"else\": ";
    false_stmt->print();
    std::cout << "\n}\n}";
}

void while_astnode :: print(){
    std::cout << "{\n\"while\": {\n";
    std::cout << "\"cond\": ";
    cond->print();
    std::cout << ",\n";
    std::cout << "\"stmt\": ";
    stmt->print();
    std::cout << "\n}\n}";
}

void for_astnode :: print(){
    std::cout << "{\n\"for\": {\n";
    std::cout << "\"init\": ";
    init->print();
    std::cout << ",\n";
    std::cout << "\"guard\": ";
    guard->print();
    std::cout << ",\n";
    std::cout << "\"step\": ";
    step->print();
    std::cout << ",\n";
    std::cout << "\"body\": ";
    stmt->print();
    std::cout << "\n}\n}";
}

void op_binary_astnode :: print(){
    std::cout << "{\n\"op_binary\": {\n";
    std::cout << "\"op\": \"" << op << "\",\n";
    std::cout << "\"left\": ";
    left->print();
    std::cout << ",\n";
    std::cout << "\"right\": ";
    right->print();
    std::cout << "\n}\n}";
}

void op_unary_astnode :: print(){
    std::cout << "{\n\"op_unary\": {\n";
    std::cout << "\"op\": \"" << op << "\",\n";
    std::cout << "\"child\": ";
    expr->print();
    std::cout << "\n}\n}";
}

void assignE_astnode :: print(){
    std::cout << "{\n\"assignE\": {\n";
    std::cout << "\"left\": ";
    left->print();
    std::cout << ",\n";
    std::cout << "\"right\": ";
    right->print();
    std::cout << "\n}\n}";
}

void funcall_astnode :: print(){
    std::cout << "{\n\"funcall\": {\n";
    std::cout << "\"fname\": ";
    fname->print();
    std::cout << ",\n";
    std::cout << "\"params\": [\n";
    int n = args.size();
    for (int i=0;i<n;i++){
        args[i]->print();
        if (i != n-1) std::cout << ",\n";
    }
    std::cout << "\n]\n}\n}";
}

void floatconst_astnode :: print(){
    std::cout << "{\n\"floatconst\": " << val << "\n}";
}

void intconst_astnode :: print(){
    std::cout << "{\n\"intconst\": " << val << "\n}";
}

void stringconst_astnode :: print(){
    std::cout << "{\n\"stringconst\": " << val << "\n}";
}

void identifier_astnode :: print(){
    std::cout << "{\n\"identifier\": \"" << id << "\"\n}";
}

void member_astnode :: print(){
    std::cout << "{\n\"member\": {\n";
    std::cout << "\"struct\": ";
    expr->print();
    std::cout << ",\n";
    std::cout << "\"field\": ";
    identifier->print();
    std::cout << "\n}\n}";
}

void arrow_astnode :: print(){
    std::cout << "{\n\"arrow\": {\n";
    std::cout << "\"pointer\": ";
    expr->print();
    std::cout << ",\n";
    std::cout << "\"field\": ";
    identifier->print();
    std::cout << "\n}\n}";
}

void arrayref_astnode :: print(){
    std::cout << "{\n\"arrayref\": {\n";
    std::cout << "\"array\": ";
    array->print();
    std::cout << ",\n";
    std::cout << "\"index\": ";
    idx->print();
    std::cout << "\n}\n}"; 
}