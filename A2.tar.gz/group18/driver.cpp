#include "scanner.hh"
#include "parser.tab.hh"
#include "ast.hh"

#include <fstream>
#include <map>
#include <string>

using namespace std;

SymTab gst;
SymTab gstfun, gststruct;
string filename;
extern std::map<std::string, abstract_astnode*> ast;
std::map<std::string, datatype> predefined {
          	{"printf", createtype(VOID_TYPE)},
          	{"scanf", createtype(VOID_TYPE)}
};

int main(int argc, char **argv){
	
	fstream in_file, out_file;
	in_file.open(argv[1], ios::in);

	IPL::Scanner scanner(in_file);
	IPL::Parser parser(scanner);

#ifdef YYDEBUG
	parser.set_debug_level(1);
#endif
	parser.parse();

	// create gstfun with function entries only
	for (const auto& entry : gst.entries){
		if (entry.second.varfun == "fun")
			gstfun.entries[entry.first] = entry.second;
	}

	// create gststruct with struct entries only
	for (const auto& entry : gst.entries){
		if (entry.second.varfun == "struct")
			gststruct.entries[entry.first] = entry.second;
	}

	// start the JSON printing
	cout << "{\"globalST\": [\n";
	gst.print(true);
	cout << "],\n";
	cout << "\"structs\": [";
	for (auto it = gststruct.entries.begin(); it != gststruct.entries.end(); ++it){
		cout << "\n{\n";
		cout << "\"name\": "
			 << "\"" << it->first << "\",\n";
		cout << "\"localST\": [";
		it->second.symtab->print(false);
		cout << "]\n";
		cout << "}";
		cout << (next(it, 1) != gststruct.entries.end() ? "," : "\n");
	}

	cout << "],\n";
	cout << "\"functions\": [";

	for (auto it = gstfun.entries.begin(); it != gstfun.entries.end(); ++it){
		cout << "\n{\n";
		cout << "\"name\": "
			 << "\"" << it->first << "\",\n";
		cout << "\"localST\": [";
		it->second.symtab->print(false);
		cout << "]\n,\n";
		cout << "\"ast\": ";
		ast[it->first]->print();
		cout << "}";
		cout << (next(it, 1) != gstfun.entries.end() ? "," : "\n");
	}

	cout << "]\n}\n";
	fclose(stdout);

	exit(0);
}
